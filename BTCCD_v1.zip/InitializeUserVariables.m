function InitializeUserVariables(hObject, ~, handles)

% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (TCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%INITIALIZEUSERVARIABLES Initialize all user variables

global PIEdat                                                              % user data structure

if ~isempty(PIEdat)                                                        % if the data structure already exists
    defaultdirectory = PIEdat.defaultdirectory;                            % keep the default directory
    PIEdat = [];                                                           % reset the data structure
    PIEdat.defaultdirectory = defaultdirectory;
else
    PIEdat.defaultdirectory = cd;                                          % set the current directory as default
end

PIEdat.path = '';                                                          % reset path name 
PIEdat.filenameShort = '';                                                 % reset file name
PIEdat.l_fn = 0;                                                           % set number of measurements to '0'
PIEdat.INPUT = [];                                                         % reset the input TTTR data
PIEdat.donor_chan = 2;                                                     % set default donor channel
PIEdat.acceptor_chan = 1;                                                  % set default acceptor channel
PIEdat.measurementTime = [];                                               % reset measurement time
PIEdat.T_end = [];                                                         % reset last macro time
PIEdat.numberMicroChannels = [];                                           % reset number of micro channels
PIEdat.dt_start_window_FRET = 30;                                          % set default starting time channel of FRET window
PIEdat.dt_start_window_PIE = 1600;                                         % set default starting time channel of PIE window
PIEdat.dt_end_window_FRET = PIEdat.dt_start_window_FRET + 1470;            % set default ending time channel of FRET window
PIEdat.dt_end_window_PIE = PIEdat.dt_start_window_PIE + 1500;              % set default ending time channel of PIE window
PIEdat.mPIE = 2;                                                           % set default width of moving average filter for PIE trace
PIEdat.mDA = 2;                                                            % set default width of moving average filter for D+A FRET trace  
PIEdat.bg_IPD_PIE = [];                                                    % reset mean IPD of the acceptor trace in PIE window
PIEdat.bg_IPD_DA = [];                                                     % reset mean IPD of the acceptor trace in PIE window
PIEdat.IPDburstThreshold_PIE_A = 50;                                         % set default burst identification threshold of PIE IPD trace in �s
PIEdat.IPDburstThreshold_FRET_DA = 50;                                          % set default burst identification threshold of D+A FRET IPD trace in �s
PIEdat.IPDthres_bg_fraction_PIE = 0.2;
PIEdat.IPDthres_bg_fraction_FRET = 0.2;
PIEdat.l_IPDburstThreshold_FRET_DA = log10(PIEdat.IPDburstThreshold_FRET_DA);        % save log10 of PIE IPD burst identification threshold
PIEdat.l_IPDburstThreshold_PIE_A = log10(PIEdat.IPDburstThreshold_PIE_A);          % save log10 of D+A FRET IPD burst identification threshold
PIEdat.PIEburstThreshold = 20;                                             % set default threshold for number of photons per burst in PIE trace
PIEdat.FRETburstThreshold = 20;                                            % set default threshold for number of photons per burst in D+A FRET trace
PIEdat.ALLburstThreshold = 40;
PIEdat.FRET_thresholdDA = 20;                                              % Threshold for D+A counts for burst in FRET window
PIEdat.directAexc = 0.0775;
PIEdat.time_resolution = 0.016;                                            % set time resolution for TCSPC channels
PIEdat.bin_width=40000;                                                    % set default bin width (default 200ns)
PIEdat.alpha = 0.640;
PIEdat.gamma = 1.07;
PIEdat.AutoThreshold = true;

% Set GUI objects to default values
set(handles.ET_DonorChannel, 'String', PIEdat.donor_chan);
set(handles.ET_AcceptorChannel, 'String', PIEdat.acceptor_chan);
set(handles.ET_StartFRETChannel, 'String', PIEdat.dt_start_window_FRET);
set(handles.ET_StartPIEChannel, 'String', PIEdat.dt_start_window_PIE);
set(handles.ET_EndFRETChannel, 'String', PIEdat.dt_end_window_FRET);
set(handles.ET_EndPIEChannel, 'String', PIEdat.dt_end_window_PIE);
set(handles.ET_MovingAverageWidth_PIE, 'String', PIEdat.mPIE);
set(handles.ET_MovingAverageWidth_DA, 'String', PIEdat.mDA);
set(handles.ET_IPDburstThreshold_PIE, 'String', PIEdat.IPDburstThreshold_PIE_A);
set(handles.ET_IPDburstThreshold_DA, 'String', PIEdat.IPDburstThreshold_FRET_DA);
set(handles.ET_IPDthres_bg_fraction_PIE, 'String', PIEdat.IPDthres_bg_fraction_PIE);
set(handles.ET_IPDthres_bg_fraction_FRET, 'String', PIEdat.IPDthres_bg_fraction_FRET);
set(handles.ET_PIEBurstThresh, 'String', PIEdat.PIEburstThreshold);
set(handles.ET_FRETBurstThresh, 'String', PIEdat.FRETburstThreshold);
if isfield(handles, 'ET_allBurstThresh')
    set(handles.ET_allBurstThresh, 'String', PIEdat.ALLburstThreshold);
end
    
if isfield(handles, 'ET_threshold_FRET_DA')
    set(handles.ET_threshold_FRET_DA, 'String', PIEdat.FRET_thresholdDA);
    set(handles.ET_directExc, 'String', PIEdat.directAexc);
    set(handles.ET_ALPHA, 'String', PIEdat.alpha);
    set(handles.ET_GAMMA, 'String', PIEdat.gamma);
    set(handles.CB_PIEselection, 'Value', get(handles.CB_PIEselection, 'Max'));
end 

set(handles.ET_IPDburstThreshold_PIE,'Enable','off');
set(handles.ET_IPDburstThreshold_DA,'Enable','off');
set(handles.ET_IPDthres_bg_fraction_FRET,'Enable','on')
set(handles.ET_IPDthres_bg_fraction_PIE,'Enable','on')

set(handles.ST_datPath, 'String', '');
set(handles.ST_Stochiometry, 'String', 'xA0 = N.A.    xD0 = N.A.    xDA = N.A.');
set(handles.CB_AutomatedThreshold, 'Value', get(handles.CB_AutomatedThreshold, 'Max'));
set(handles.ST_TimeResolution, 'String', 'time res. = N.A.');

% Clear all axes (plots)
cla(handles.AX_TCSPC,'reset');
cla(handles.AX_IPDtrace,'reset');
cla(handles.AX_Dhist,'reset');
cla(handles.AX_Ahist,'reset');
cla(handles.AX_PIEhist,'reset');
cla(handles.AX_DAhist,'reset');
cla(handles.AX_BurstWidthPIE,'reset');
cla(handles.AX_BurstWidthDA,'reset');
cla(handles.AX_MolecularBrightnessPIE,'reset');
cla(handles.AX_MolecularBrightnessDA,'reset');
if isfield(handles, 'AX_FRETefficiency')
    cla(handles.AX_FRETefficiency,'reset');
end
if isfield(handles, 'AX_Coincidence')
    cla(handles.AX_Coincidence,'reset');
end
if isfield(handles, 'AX_CoincThres')
    cla(handles.AX_CoincThres,'reset');
end  

guidata(hObject, handles);                                                 % update handles structure

end

