function CalculateBursts(hObject, eventdata, handles)
% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (TCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%CALCULATEBURSTCOORDINATES Calculates bursts parameters(=coordinates) of sm
%measurement

% History:

% Adapted from Matteo Gabba, Apr 2014
% This is an update of the script: FRET_4SPAD_autoIPDtau_ht3_bias_corr7.m
% which was used to analize the data presented in the paper about PGK
% interdomain dynamics (Gabba et al., 2014).

% The following features are added/modified with respect to the previous 
% version:
% (1)   The backgrounds (BG) for each binned trace are now calculated from
%       the background count rates <bg> which are obtained from the 
%       corresponding IPD trace and not from binned traces.(Matteo, 4/2014) 
% (2)   I sort the macro times in an ascending manner after merging the
%       parallel and the perpendicular selected photons. I need this
%       feature for correlation analysis where a stream of sorted
%       macrotimes is required. I also need it if I want to build binwise
%       time traces. (Matteo, Mag 2014)
% (3)   Added burst selection in FRET trace (Henning, 12/2014)

% ToDo:

% (1)   Implement background correction for burst intensities
% (2)   Set different threshold depending whether conic is calculated or
%       FRET efiiciencies (Matteo set 5 percent of bg PIE IPD)
% (3)   Make GUI for FRET threshold input

global PIEdat

% initialize variables
burst_width_PIE_ms = cell(1,PIEdat.l_fn);
burst_width_FRET_ms = cell(1,PIEdat.l_fn);
MB_PIE = cell(1,PIEdat.l_fn);
MB_FRET = cell(1,PIEdat.l_fn);
flag_more_coinc_PIE = true;                                                % flag if number bursts PIE > FRET

wbarh = waitbar(0,'Calculating bursts ...');                          % create waitbar
disp('-------------------------------------------------')
disp(['Calculating bursts for ' num2str(PIEdat.l_fn) ' file(s) ...']);                 % display how many files are processed

for file = 1:PIEdat.l_fn
    
disp(['... file ' num2str(file)]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Identification of all Bursts
%   All bursts in PIE and FRET window are selected with the Inter-Photon-Distance
%   (IPD) criterion, i.e. the IPD trace has to drop below a given
%   threshold. In the PIE window the acceptor signal is considered and in
%   the FRET window the merged donor+acceptor signal is considered.

% Create binary vector for selection of burst in the IPD trace
hPIE = PIEdat.l_smooth_IPD_PIE_A{file} <= PIEdat.l_IPDburstThreshold_PIE_A(file);            % length(hPIE)=length(t_PIE)       
hDA = PIEdat.l_smooth_IPD_FRET_DA{file} <= PIEdat.l_IPDburstThreshold_FRET_DA(file);         % length(hDA)=length(t_DA)     

% Add a zero at the beginning and at the end for boundary reasons
hPIE_LB = logical(cat(1,0,hPIE));                                          % add '0' at start of vector => lower boundary (LB)
hPIE_UB = logical(cat(1,hPIE,0));                                          % add '0' at end of vector => upper boundary (UB)
hDA_LB = logical(cat(1,0,hDA));                                            % same for FRET window
hDA_UB = logical(cat(1,hDA,0));

% Identify start and end positions of bursts 
t_startPIE = logical(hPIE_UB-hPIE_LB==1);                                  % UB-HB = 1 for start of burst                                 
t_endPIE = logical(hPIE_UB-hPIE_LB==-1);                                   % UB-LB = -1 for end of burst
t_startFRET = logical(hDA_UB-hDA_LB==1);                                   % same for FRET window
t_endFRET = logical(hDA_UB-hDA_LB==-1);

clear hPIE_LB hDA_LB hPIE_UB hDA_UB hDA hPIE;

% Get rid of the two points added before
t_startPIE(end) = [];
t_startFRET(end) = [];
t_endPIE(1) = [];
t_endFRET(1) = [];

% Select bursts with same start and end macrotime
t_start_end_PIE = t_startPIE + t_endPIE;                                   % add binary start and end vectors
ind_PIE_same_start_stop = ~logical(t_start_end_PIE==2);                    % if the same photon is marked as start and stop the sum is '2'
t_start_end_FRET = t_startFRET + t_endFRET;
ind_FRET_same_start_stop = ~logical(t_start_end_FRET==2);

% Also select bursts with only 1 photon (they induce artifically small
% diffusion times and high molecular brightness')
t_startPIE_LB = logical(cat(1,0,t_startPIE));                              % add a zero at beginning, shift all indices by 1
t_endPIE_UB = logical(cat(1,t_endPIE,0));                                  % add a zero at end
t_start_end_PIE_1photon = t_startPIE_LB + t_endPIE_UB;                     % add binary start and end vectors
ind_PIE_1photon = ~logical(t_start_end_PIE_1photon==2);                    % if shifted start photon is at same index as end the sum is '2'
ind_PIE_1photon_start = ind_PIE_1photon(2:end);                            % shift indices back to intitial state (delete 1st)
ind_PIE_1photon_end = ind_PIE_1photon(1:end-1);                            % shift indices back to intitial state (delete last)

t_startFRET_LB = logical(cat(1,0,t_startFRET));                            % same for FRET window
t_endFRET_UB = logical(cat(1,t_endFRET,0));
t_start_end_FRET_1photon = t_startFRET_LB + t_endFRET_UB;                  
ind_FRET_1photon = ~logical(t_start_end_FRET_1photon==2);
ind_FRET_1photon_start = ind_FRET_1photon(2:end);
ind_FRET_1photon_end = ind_FRET_1photon(1:end-1);

% Delete all the selected bursts
ind_PIE_start = ind_PIE_same_start_stop & ind_PIE_1photon_start;           % merge indices of bursts without same start/stop and 1 photon/burst
ind_PIE_end = ind_PIE_same_start_stop & ind_PIE_1photon_end;               % same for end of burst indices
t_startPIE = t_startPIE & ind_PIE_start;                                   % select that bursts (more than 1 photon/burst)
t_endPIE = t_endPIE & ind_PIE_end;                                         % same for end of burst indices

ind_FRET_start = ind_FRET_same_start_stop & ind_FRET_1photon_start;        % same for FRET window
ind_FRET_end = ind_FRET_same_start_stop & ind_FRET_1photon_end;
t_startFRET = t_startFRET & ind_FRET_start;
t_endFRET = t_endFRET & ind_FRET_end;

clear t_start_end_PIE ind_PIE_same_start_stop t_startPIE_LB t_endPIE_UB
clear t_start_end_PIE_1photon ind_PIE_1photon ind_PIE_1photon_start
clear ind_PIE_1photon_end ind_PIE_start ind_PIE_end

clear t_start_end_FRET ind_FRET_same_start_stop t_startFRET_LB t_endFRET_UB
clear t_start_end_FRET_1photon ind_FRET_1photon ind_FRET_1photon_start
clear ind_FRET_1photon_end ind_FRET_start ind_FRET_end

% Convert binary vectors 't_start' and 't_end' to macrotime vectors
PIEdat.t_PIE_start{file} = PIEdat.t_PIE_A{file}.*t_startPIE;                            % convert to macro time postion
PIEdat.t_PIE_start{file}(PIEdat.t_PIE_start{file}==0) = [];                                          % delete all zero entries
PIEdat.t_FRET_start{file} = PIEdat.t_FRET_DA{file}.*t_startFRET;                        % convert to macro time postion
PIEdat.t_FRET_start{file}(PIEdat.t_FRET_start{file}==0) = [];                                        % delete all zero entries
PIEdat.t_PIE_end{file} = PIEdat.t_PIE_A{file}.*t_endPIE;                                % convert to macro time postion
PIEdat.t_PIE_end{file}(PIEdat.t_PIE_end{file}==0) = [];                                              % delete all zero entries
PIEdat.t_FRET_end{file} = PIEdat.t_FRET_DA{file}.*t_endFRET;                            % convert to macro time postion
PIEdat.t_FRET_end{file}(PIEdat.t_FRET_end{file}==0) = [];                                            % delete all zero entries

clear t_startPIE t_startFRET t_endPIE t_endFRET

% Correct if trace starts with end of burst or ends with start of burst
if length(PIEdat.t_FRET_end{file}) > length(PIEdat.t_FRET_start{file})                               % if end vector is larger => trace started with end of burst
    PIEdat.t_FRET_end{file}(1)=[];                                                      % delete that first end entry
elseif length(PIEdat.t_FRET_start{file}) > length(PIEdat.t_FRET_end{file})                           % if start vector is larger => trace ended with start of burst
    PIEdat.t_FRET_start{file}(end) =[];                                                 % delete that last start entry
end

if length(PIEdat.t_PIE_end{file}) > length(PIEdat.t_PIE_start{file})                                 % same for PIE window
    PIEdat.t_PIE_end{file}(1)=[];
elseif length(PIEdat.t_PIE_start{file}) > length(PIEdat.t_PIE_end{file})
    PIEdat.t_PIE_start{file}(end) =[];    
end

% Quit if there are no burst in one trace
if isempty(PIEdat.t_PIE_start{file})
    errordlg('No bursts in PIE channel.', 'Error', 'modal')
    return;
elseif isempty(PIEdat.t_FRET_start{file})
    errordlg('No bursts in FRET channel.', 'Error', 'modal')
    return;
end    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Calculation of Parameters for all Bursts (dwell time, intensitiy, ...)

% ###BURST WIDTH###
burst_width_PIE_ms{file} = (PIEdat.t_PIE_end{file}-PIEdat.t_PIE_start{file}).*10^-6;                 % convert from ns to ms
burst_width_FRET_ms{file} = (PIEdat.t_FRET_end{file}-PIEdat.t_FRET_start{file}).*10^-6;              % convert from ns to ms
PIEdat.meanBurstWidthPIE{file} = mean(burst_width_PIE_ms{file});           % calculate mean burst width
PIEdat.meanBurstWidthFRET{file} = mean(burst_width_FRET_ms{file});
PIEdat.stdBurstWidthPIE{file} = std(burst_width_PIE_ms{file});             % calculate standard deviation of burst width
PIEdat.stdBurstWidthFRET{file} = std(burst_width_FRET_ms{file});
PIEdat.semBurstWidthPIE{file} = PIEdat.stdBurstWidthPIE{file}/sqrt(length(burst_width_PIE_ms{file}));   % calculate standard error on mean burst width
PIEdat.semBurstWidthFRET{file} = PIEdat.stdBurstWidthFRET{file}/sqrt(length(burst_width_FRET_ms{file}));

% check for aggregates
thr_aggr = 100;                                                             % if burst parameters exceed mean values multiplied by that factor => aggregate is idetified 
ind_aggreg_burst_PIE = find(burst_width_PIE_ms{file} > thr_aggr*mean(burst_width_PIE_ms{file}));    % check for aggregates, they exists if dwell time is huge compared to mean
ind_aggreg_burst_FRET = find(burst_width_FRET_ms{file}>thr_aggr*mean(burst_width_FRET_ms{file}));         % same for FRET window
if ~isempty(ind_aggreg_burst_PIE)
    burst_width_PIE_ms{file}(ind_aggreg_burst_PIE)=[];                     % delete the dwell time of this aggregates
    PIEdat.t_PIE_start{file}(ind_aggreg_burst_PIE) = [];                                % delete the start time of this aggregates
    PIEdat.t_PIE_end{file}(ind_aggreg_burst_PIE) = [];                                  % delete the end time of this aggregates
    PIEdat.flags.aggreg_burst_PIE(file)=1;                                 % set aggregates flag
    disp([num2str(length(ind_aggreg_burst_PIE)) ' aggregate(s) in PIE window detected and deleted!!!']);
else
    PIEdat.flags.aggreg_burst_PIE(file)=0;
end
if ~isempty(ind_aggreg_burst_FRET)
    burst_width_FRET_ms{file}(ind_aggreg_burst_FRET)=[];                   % same for FRET window
    PIEdat.t_FRET_start{file}(ind_aggreg_burst_FRET) = [];
    PIEdat.t_FRET_end{file}(ind_aggreg_burst_FRET) = [];
    PIEdat.flags.aggreg__burst_FRET(file)=1;
    disp([num2str(length(ind_aggreg_burst_FRET)) ' aggregate(s) in FRET window detected and deleted!!!']);
else
    PIEdat.flags.aggreg_burst_FRET(file)=0;
end    

clear ind_aggreg_burst_PIE ind_aggreg_burst_FRET

% plot burst width histograms
if file==1
    % calculate histograms of burst widths
    x_BurstWidth_distr_PIE = 0:0.1:max(burst_width_PIE_ms{1});
    x_BurstWidth_distr_FRET = 0:0.1:max(burst_width_FRET_ms{1});
    hist_BurstWidth_PIE = hist(burst_width_PIE_ms{file}, x_BurstWidth_distr_PIE);
    hist_BurstWidth_FRET = hist(burst_width_FRET_ms{file}, x_BurstWidth_distr_FRET);

    % plot burst width histograms
    cla(handles.AX_BurstWidthPIE,'reset')
    hist(handles.AX_BurstWidthPIE,burst_width_PIE_ms{1},x_BurstWidth_distr_PIE);
    xlabel(handles.AX_BurstWidthPIE,'burst width / ms')
    ylabel(handles.AX_BurstWidthPIE,'# of bursts')
    text(0,0.9*max(hist_BurstWidth_PIE),['<Burst Width> = ', num2str(PIEdat.meanBurstWidthPIE{1},3) ' ms'],'FontSize',10,'EdgeColor','black','Parent', handles.AX_BurstWidthPIE);
    
    cla(handles.AX_BurstWidthDA,'reset')
    hist(handles.AX_BurstWidthDA,burst_width_FRET_ms{1},x_BurstWidth_distr_FRET);
    xlabel(handles.AX_BurstWidthDA,'burst width / ms')
    ylabel(handles.AX_BurstWidthDA,'# of bursts')
    text(0,0.9*max(hist_BurstWidth_FRET),['<Burst Width> = ', num2str(PIEdat.meanBurstWidthFRET{1},3) ' ms'],'FontSize',10,'EdgeColor','black', 'Parent', handles.AX_BurstWidthDA);
                                                              
    guidata(hObject, handles);                                             % update handles structure
    
    clear hist_BurstWidth_PIE hist_BurstWidth_FRET 
    clear x_BurstWidth_distr_PIE x_BurstWidth_distr_FRET
end

% ###BURST INTENSITIES###
% get the position of the bursts in the macro time vector
% pos_t*window*_*channel* contains the postion in the macro time vector of
% channel *chanel* for the bursts selected in the time window *window*
[~,pos_tPIE_PIE_start] = histc(PIEdat.t_PIE_start{file},PIEdat.t_PIE_A{file});          % get starting position of bursts in macrotime vector for PIE channel 
[~,pos_tPIE_PIE_end] = histc(PIEdat.t_PIE_end{file},PIEdat.t_PIE_A{file});              % get ending position of bursts in macrotime vector for PIE channel
[~,pos_tFRET_DA_start] = histc(PIEdat.t_FRET_start{file},PIEdat.t_FRET_DA{file});       % get starting position of bursts in macrotime vector for FRET channel
[~,pos_tFRET_DA_end] = histc(PIEdat.t_FRET_end{file},PIEdat.t_FRET_DA{file});           % get ending position of bursts in macrotime vector for FRET channel
[~,pos_tPIE_FRET_D_start] = histc(PIEdat.t_PIE_start{file},PIEdat.t_FRET_D{file});      % get starting position of bursts in macrotime vector for PIE channel 
[~,pos_tPIE_FRET_D_end] = histc(PIEdat.t_PIE_end{file},PIEdat.t_FRET_D{file});          % get ending position of bursts in macrotime vector for PIE channel
[~,pos_tPIE_FRET_A_start] = histc(PIEdat.t_PIE_start{file},PIEdat.t_FRET_A{file});      % get starting position of bursts in macrotime vector for PIE channel 
[~,pos_tPIE_FRET_A_end] = histc(PIEdat.t_PIE_end{file},PIEdat.t_FRET_A{file});
[~,pos_tPIE_FRET_DA_start] = histc(PIEdat.t_PIE_start{file},PIEdat.t_FRET_DA{file});    % get starting position of bursts in macrotime vector for PIE channel 
[~,pos_tPIE_FRET_DA_end] = histc(PIEdat.t_PIE_end{file},PIEdat.t_FRET_DA{file});
[~,pos_tFRET_D_start] = histc(PIEdat.t_FRET_start{file},PIEdat.t_FRET_D{file});         % get starting position of bursts in macrotime vector for FRET channel
[~,pos_tFRET_D_end] = histc(PIEdat.t_FRET_end{file},PIEdat.t_FRET_D{file});             % get ending position of bursts in macrotime vector for FRET channel
[~,pos_tFRET_A_start] = histc(PIEdat.t_FRET_start{file},PIEdat.t_FRET_A{file});         % get starting position of bursts in macrotime vector for FRET channel
[~,pos_tFRET_A_end] = histc(PIEdat.t_FRET_end{file},PIEdat.t_FRET_A{file});             % get ending position of bursts in macrotime vector for FRET channel
[~,pos_tFRET_PIE_start] = histc(PIEdat.t_FRET_start{file},PIEdat.t_PIE_A{file});
[~,pos_tFRET_PIE_end] = histc(PIEdat.t_FRET_end{file},PIEdat.t_PIE_A{file});

% get the intensities of the bursts
% I_*window*_*channel* contains the number of photons of
% channel *chanel* for the bursts selected in the time window *window*
PIEdat.I_PIE_PIE{file} = pos_tPIE_PIE_end - pos_tPIE_PIE_start;                         % calculate intensity in PIE channel for bursts selected in PIE trace
PIEdat.I_PIE_FRET_D = pos_tPIE_FRET_D_end - pos_tPIE_FRET_D_start;                % calculate intensity in D FRET channel for bursts selected in PIE trace
PIEdat.I_PIE_FRET_A = pos_tPIE_FRET_A_end - pos_tPIE_FRET_A_start;                % calculate intensity in A FRET channel for bursts selected in PIE trace
PIEdat.I_PIE_FRET_DA = pos_tPIE_FRET_DA_end - pos_tPIE_FRET_DA_start;
PIEdat.I_FRET_FRET_DA{file} = pos_tFRET_DA_end - pos_tFRET_DA_start;                    % calculate intensity in DA FRET channel for bursts selected in FRET trace
PIEdat.I_FRET_FRET_D = pos_tFRET_D_end - pos_tFRET_D_start;                       % calculate intensity in D FRET channel for bursts selected in FRET trace
PIEdat.I_FRET_FRET_A = pos_tFRET_A_end - pos_tFRET_A_start;                       % calculate intensity in A FRET channel for bursts selected in FRET trace
PIEdat.I_FRET_PIE = pos_tFRET_PIE_end - pos_tFRET_PIE_start;                      % calculate intensity in PIE channel for bursts selected in FRET trace

clear pos_tPIE_PIE_start pos_tPIE_PIE_end
clear pos_tFRET_DA_start pos_tFRET_DA_end
clear pos_tPIE_FRET_D_start pos_tPIE_FRET_D_end
clear pos_tPIE_FRET_A_start pos_tPIE_FRET_A_end 
clear pos_tPIE_FRET_DA_start pos_tPIE_FRET_DA_end
clear pos_tFRET_D_start pos_tFRET_D_end 
clear pos_tFRET_A_start pos_tFRET_A_end 
clear pos_tFRET_PIE_start pos_tFRET_PIE_end

% calculate parameters of the intensity distribution 
PIEdat.mean_I_PIE(file) = mean(PIEdat.I_PIE_PIE{file});                                              % mean number of photons per bursts in PIE channel
PIEdat.mean_I_FRET(file) = mean(PIEdat.I_FRET_FRET_DA{file});                                        % mean number of photons per burst in FRET channel
%PIEdat.PIEburstThreshold{file} = PIEdat.mean_I_PIE(file);                               % set default threshold for number of photons per burst in PIE trace
%PIEdat.FRETburstThreshold{file} = PIEdat.mean_I_FRET(file);
%set(handles.ET_PIEburstThreshold, 'String', num2str(PIEdat.PIEburstThreshold{file},3));
%set(handles.ET_FRETburstThreshold, 'String', num2str(PIEdat.FRETburstThreshold{file},3));

% calculate molecular brightness (=photons/burst duration)
MB_PIE{file} = PIEdat.I_PIE_PIE{file}./burst_width_PIE_ms{file};
MB_FRET{file} = PIEdat.I_FRET_FRET_DA{file}./burst_width_FRET_ms{file};
PIEdat.MB_PIE_mean{file} = mean(MB_PIE{file});
PIEdat.MB_FRET_mean{file} = mean(MB_FRET{file});
PIEdat.MB_PIE_std{file} = std(MB_PIE{file});
PIEdat.MB_FRET_std{file} = std(MB_FRET{file});
PIEdat.MB_PIE_sem{file} = PIEdat.MB_PIE_std{file}/sqrt(length(MB_PIE{file}));
PIEdat.MB_FRET_sem{file} = PIEdat.MB_FRET_std{file}/sqrt(length(MB_FRET{file}));

% check for aggregates 
thr_aggr = 100; 
ind_aggreg_PIE = find(MB_PIE{file}>thr_aggr*mean(MB_PIE{file}));           % check for aggregates, they exists if MB larger
ind_aggreg_FRET = find(MB_FRET{file}>thr_aggr*mean(MB_FRET{file}));        % 20*mean(MB) is present, additionally they can also arise due to a tiny dwell time
if ~isempty(ind_aggreg_PIE)
    disp(['Still ' num2str(length(ind_aggreg_PIE)) ' aggregate(s) in PIE window !!! Check measurement!!!']);
end
if ~isempty(ind_aggreg_FRET)
    disp(['Still ' num2str(length(ind_aggreg_FRET)) ' aggregate(s) in FRET window !!! Check measurement!!!']);
end 

clear ind_aggreg_PIE ind_aggreg_FRET

% plot distribution of molecular brightness
if file==1
    x_MB_distr_PIE = 0:1:max(MB_PIE{1});
    x_MB_distr_FRET = 0:1:max(MB_FRET{1});
    hist_MB_PIE = hist(MB_PIE{1},x_MB_distr_PIE);
    hist_MB_FRET = hist(MB_FRET{1},x_MB_distr_FRET);
    pos_max_MB_PIE = find(hist_MB_PIE==max(hist_MB_PIE));
    pos_max_MB_PIE = pos_max_MB_PIE(1);
    pos_max_MB_FRET = find(hist_MB_FRET==max(hist_MB_FRET));
    pos_max_MB_FRET = pos_max_MB_FRET(1);

    % plot molecular brightness histograms                                                                    
    cla(handles.AX_MolecularBrightnessPIE);                                % clear current axes
    bar(handles.AX_MolecularBrightnessPIE,x_MB_distr_PIE,hist_MB_PIE);
    xlabel(handles.AX_MolecularBrightnessPIE,'molecular brightness / kcpm')
    ylabel(handles.AX_MolecularBrightnessPIE,'# of bursts')
    text(1.2*pos_max_MB_PIE,0.9*max(hist_MB_PIE),['<MB> = ', num2str(PIEdat.MB_PIE_mean{1},3) ' kcpm'],'FontSize',10,'EdgeColor','black', 'Parent',handles.AX_MolecularBrightnessPIE);

    cla(handles.AX_MolecularBrightnessDA);
    bar(handles.AX_MolecularBrightnessDA,x_MB_distr_FRET, hist_MB_FRET);
    xlabel(handles.AX_MolecularBrightnessDA,'molecular brightness / kcpm')
    ylabel(handles.AX_MolecularBrightnessDA,'# of bursts')
    text(1.2*pos_max_MB_FRET,0.9*max(hist_MB_FRET),['<MB> = ', num2str(PIEdat.MB_FRET_mean{1},  3) ' kcpm'],'FontSize',10,'EdgeColor','black','Parent',handles.AX_MolecularBrightnessDA);

    guidata(hObject, handles);
    
end

    % create plot of burst duration vs. burst intensity
    x_I_distr_PIE = 0:1:max(PIEdat.I_PIE_PIE{file});
    hist_I_PIE = hist(PIEdat.I_PIE_PIE{file}, x_I_distr_PIE);
    x_I_distr_FRET = 0:1:max(PIEdat.I_FRET_FRET_DA{file});
    hist_I_FRET = hist(PIEdat.I_FRET_FRET_DA{file}, x_I_distr_FRET);
    x_T_PIE = 0:0.1:max(burst_width_PIE_ms{file});
    hist_T_PIE = hist(burst_width_PIE_ms{file}, x_T_PIE);
    x_T_FRET = 0:0.1:max(burst_width_FRET_ms{file});
    hist_T_FRET = hist(burst_width_FRET_ms{file}, x_T_FRET);
    [nPIE,cPIE] = hist3([PIEdat.I_PIE_PIE{file} burst_width_PIE_ms{file}],{x_I_distr_PIE x_T_PIE});
    [nFRET,cFRET] = hist3([PIEdat.I_FRET_FRET_DA{file} burst_width_FRET_ms{file}],{x_I_distr_FRET x_T_FRET});
   
    fig_burst_T_vs_I_PIE = figure('Visible', 'on');
    axes('position',[0.7 0.2 0.2 0.5])
    stairs(hist_T_PIE,1:length(hist_T_PIE),'r','LineWidth',4)
    box on
    set(gca,'fontsize',12)
    set(gca,'ytickLabel',[])
    set(gca,'FontSize',16, 'FontWeight','bold')

    axes('position',[0.1 0.7 0.6 0.2])
    stairs(1:length(hist_I_PIE),hist_I_PIE,'r','LineWidth',4)
    box on
    set(gca,'fontsize',12)
    set(gca,'xtickLabel',[])
    set(gca,'FontSize',16,'FontWeight','bold')
    title('Bursts in PIE window');

    axes('position',[0.1 0.2 0.6 0.5])
    plot(PIEdat.I_PIE_PIE{file}, burst_width_PIE_ms{file}, 'r','Marker','.','LineStyle','none');
    hold on
    contour(cPIE{1},cPIE{2},nPIE',[1 2 3],'Fill','off','LineWidth',2);
    box on
    ylabel('burst duration / ms','FontSize',16, 'FontWeight','bold');
    xlabel('burst intensity / # \gamma','FontSize',16, 'FontWeight','bold');
    set(gca,'fontsize',12)
    set(gca,'FontSize',16, 'FontWeight','bold')
    if ~exist([PIEdat.defaultdirectory 'figures\'],'dir')
        mkdir([PIEdat.defaultdirectory 'figures\']);
    end
%    hgsave(fig_burst_T_vs_I_PIE, strcat(PIEdat.defaultdirectory, 'figures\',PIEdat.filenameShort{file},'_T_vs_I_PIE.fig'));
    close(fig_burst_T_vs_I_PIE);
    

    fig_burst_T_vs_I_FRET = figure('Visible', 'on');
    axes('position',[0.7 0.2 0.2 0.5])
    stairs(hist_T_FRET,1:length(hist_T_FRET),'r','LineWidth',4)
    box on
    xlabel('# bursts','FontSize',16, 'FontWeight','bold')
    set(gca,'fontsize',12)
    set(gca,'ytickLabel',[])
    set(gca,'FontSize',16, 'FontWeight','bold')

    axes('position',[0.1 0.7 0.6 0.2])
    stairs(1:length(hist_I_FRET),hist_I_FRET,'r','LineWidth',4)
    box on
    ylabel('# bursts','FontSize',16, 'FontWeight','bold')
    set(gca,'fontsize',12)
    set(gca,'xtickLabel',[])
    set(gca,'FontSize',16,'FontWeight','bold')
    title('Bursts in FRET window');

    axes('position',[0.1 0.2 0.6 0.5])
    plot(PIEdat.I_FRET_FRET_DA{file}, burst_width_FRET_ms{file}, 'r','Marker','.','LineStyle','none');
    hold on
    contour(cFRET{1},cFRET{2},nFRET',20,'Fill','off','LineWidth',2);
    box on
    ylabel('burst duration / ms','FontSize',16, 'FontWeight','bold');
    xlabel('burst intensity / # \gamma','FontSize',16, 'FontWeight','bold');
    set(gca,'fontsize',12)
    set(gca,'FontSize',16, 'FontWeight','bold')
    hgsave(fig_burst_T_vs_I_FRET, strcat(PIEdat.defaultdirectory, 'figures\',PIEdat.filenameShort{file},'_T_vs_I_FRET.fig'));
    close(fig_burst_T_vs_I_FRET);
    
    clear fig_burst_T_vs_I_PIE fig_burst_T_vs_I_FRET   
    clear x_MB_distr_PIE x_MB_distr_FRET 
    clear hist_MB_PIE hist_MB_FRET
    clear pos_max_MB_PIE pos_max_MB_FRET
    clear x_I_distr_PIE x_I_distr_FRET
    clear hist_I_PIE hist_I_FRET 
    clear cPIE nPIE cFRET nFRET 

waitbar(file/PIEdat.l_fn, wbarh);  
end
close(wbarh); 
disp('-------------------------------------------------')
