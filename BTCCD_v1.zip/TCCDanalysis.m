function TCCDanalysis(hObject, eventdata, handles)
% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (TCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%TCCDANALYSIS Performes a two-color coincidence detection (TCCD) analysis

global PIEdat

wbarh = waitbar(0,'Calculating TCCD values ...');                          % create waitbar
disp('-------------------------------------------------')
disp(['Calculate TCCD values for ' num2str(PIEdat.l_fn) ' file(s) ...']);                 % display how many files are processed


for file = 1:PIEdat.l_fn

disp(['... file ' num2str(file)]);
    
% initialize variables
frac_res = 0.01;
frac_end_max = 5;                                                             % number of loops for varying the threshold for number of photons
frac_end = floor(min(max(PIEdat.I_PIE_PIE{file})/PIEdat.mean_I_PIE(file),max(PIEdat.I_FRET_FRET_DA{file})/PIEdat.mean_I_FRET(file)));
if frac_end>frac_end_max
    frac_end=frac_end_max;
end

N_loops = frac_end/frac_res;
                                                              % highest fraction of photon threshold with respect to mean number
PIEburstThreshold = zeros(N_loops,1);
FRETburstThreshold = zeros(N_loops,1);
N_PIE_thres = zeros(N_loops,1);
N_PIE_coinc = zeros(N_loops,1);
N_FRET_thres = zeros(N_loops,1);
N_FRET_coinc = zeros(N_loops,1);
thr_ana = zeros(N_loops,7);

%% Selection of bursts

disp(['Mean # photons PIE= ' num2str(PIEdat.mean_I_PIE(file))]);
disp(['Mean # photons FRET= ' num2str(PIEdat.mean_I_FRET(file))]);

for thr_loop = 1:N_loops+1

disp([num2str(thr_loop) '/' num2str(N_loops)]);    
    
thr_fraction = ((thr_loop-1)/N_loops)*frac_end;
PIEburstThreshold(thr_loop) = thr_fraction*PIEdat.mean_I_PIE(file);
FRETburstThreshold(thr_loop) = thr_fraction*PIEdat.mean_I_FRET(file);

% select burst that satisfy the number of photons threshold
ePIE_PIE = find(PIEdat.I_PIE_PIE{file} >= PIEburstThreshold(thr_loop));              % indices of bursts with counts above theshold
eFRET_FRET_DA = find(PIEdat.I_FRET_FRET_DA{file} >= FRETburstThreshold(thr_loop));      % indices of bursts with counts above theshold

t_PIE_start_thres = PIEdat.t_PIE_start{file}(ePIE_PIE);                                 % select starting times of bursts (PIE trace)
t_PIE_end_thres = PIEdat.t_PIE_end{file}(ePIE_PIE);                                     % select ending times of bursts (PIE trace)
t_FRET_start_thres = PIEdat.t_FRET_start{file}(eFRET_FRET_DA);                               % select starting times of bursts (FRET trace)
t_FRET_end_thres = PIEdat.t_FRET_end{file}(eFRET_FRET_DA);                                   % select ending times of bursts (FRET trace)

I_PIE_thresh = PIEdat.I_PIE_PIE{file}(ePIE_PIE);
I_FRET_thresh = PIEdat.I_FRET_FRET_DA{file}(eFRET_FRET_DA);

clear ePIE_PIE eFRET_FRET_DA

% Quit if there are no burst that fulfil the threshold criterion
if isempty(t_PIE_start_thres)
    errordlg('No bursts in PIE channel fulfill threshold.', 'Error', 'modal')
    return;
elseif isempty(t_FRET_start_thres)
    errordlg('No bursts in FRET channel fulfill threshold.', 'Error', 'modal')
    return;
end 

% if thr_loop==1
%     % Generate and save distribution plot for # photons
%     PIEdat.optthrPIE = PIEdat.PIEburstThreshold{file};                                   % generate handy variable name
%     PIEdat.optthrFRET = PIEdat.FRETburstThreshold{file};                                 % generate handy variable name
%     x_photons_distr_PIE = 0:1:max(I_PIE_PIE);
%     x_photons_distr_FRET = 0:1:max(I_FRET_FRET_DA);
%     num_sel_bursts_PIE = length(PIEdat.I_PIE_select);                          % number of bursts that contain more photons than average in PIE channel
%     num_sel_bursts_FRET = length(PIEdat.I_FRET_DA_select);                     % number of bursts that contain more photons than average in FRET channel
%     frac_sel_bursts_PIE = num_sel_bursts_PIE / length(I_PIE_PIE);              % fraction of bursts that exceed above threshold in PIE channel
%     frac_sel_bursts_FRET = num_sel_bursts_FRET / length(I_FRET_FRET_DA);       % fraction of bursts that exceed above threshold in FRET channel
% 
%     fig_hist_phot = figure();    
%     axes('position',[0.07 0.57 0.9 0.4])
%     h_PIE = histogram(I_PIE_PIE, x_photons_distr_PIE, 'FaceColor', 'red');
%     line([PIEdat.optthrPIE PIEdat.optthrPIE], [0,  max(h_PIE.Values)], 'Color', [0 0 0], 'LineWidth', 2);
%     text(0.9*PIEdat.optthrPIE, 1.02*max(h_PIE.Values),'threshold','FontSize',12);
%     text(1.5*PIEdat.optthrPIE, 0.9*max(h_PIE.Values),['threshold \gamma = ', num2str(PIEdat.optthrPIE,  3)],'FontSize',14,'EdgeColor','black');
%     text(1.5*PIEdat.optthrPIE, 0.75*max(h_PIE.Values),['<\gamma> = ', num2str(mean_I_PIE,  3)],'FontSize',14,'EdgeColor','black');
%     text(1.5*PIEdat.optthrPIE, 0.6*max(h_PIE.Values),['<selected bursts> = ', num2str(frac_sel_bursts_PIE*100,3), '%'],'FontSize',14,'EdgeColor','black');
%     xlabel('# photons','FontSize',12, 'FontWeight','bold')
%     ylabel('occurence','FontSize',12, 'FontWeight','bold')
%     xlim([-10 max(I_PIE_PIE)+10])
%     ylim([0 max(h_PIE.Values)+10])
%     set(gca, 'FontWeight', 'bold', 'FontSize', 14)
%     legend('PIE')
%     axes('position',[0.07 0.07 0.9 0.4])
%     h_FRET = histogram(I_FRET_FRET_DA, x_photons_distr_FRET, 'FaceColor', 'blue');
%     line([PIEdat.optthrFRET PIEdat.optthrFRET], [0,  max(h_FRET.Values)], 'Color', [0 0 0], 'LineWidth', 2);
%     text(0.9*PIEdat.optthrFRET, 1.02*max(h_FRET.Values),'threshold','FontSize',12);
%     text(1.5*PIEdat.optthrFRET, 0.9*max(h_FRET.Values),['threshold \gamma = ', num2str(PIEdat.optthrFRET,  3)],'FontSize',14,'EdgeColor','black');
%     text(1.5*PIEdat.optthrFRET, 0.75*max(h_FRET.Values),['<\gamma> = ', num2str(mean_I_FRET,  3)],'FontSize',14,'EdgeColor','black');
%     text(1.5*PIEdat.optthrFRET, 0.6*max(h_FRET.Values),['<selected bursts> = ', num2str(frac_sel_bursts_FRET*100,3), '%'],'FontSize',14,'EdgeColor','black');
%     xlabel('# photons','FontSize',12, 'FontWeight','bold')
%     ylabel('occurence','FontSize',12, 'FontWeight','bold')
%     xlim([-10 max(I_FRET_FRET_DA)+10])
%     ylim([0 max(h_FRET.Values)+10])
%     set(gca, 'FontWeight', 'bold', 'FontSize', 14)
%     legend('FRET')
%     hgsave(fig_hist_phot, strcat(PIEdat.defaultdirectory,PIEdat.filenameShort{file},num2str(thr_loop),'_hist_phot.fig'));
%     close(fig_hist_phot);
%     clear fig_hist_phot h_PIE h_FRET PIEdat.optthrPIE PIEdat.optthrFRET x_photons_distr_PIE x_photons_distr_FRET
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Calculate D0,A0 and DA stochiometry using bursts in FRET and PIE window
% For each window (FRET and PIE) bursts have been selected by a drop of the
% IPD below a threshold and a threshold for the number of photons in a 
% burst. For each of this selected bursts it is checked if the IPD of the 
% other window drops below the threshold. Note that a drop below the IPD 
% threshold is sufficient to identify a coincidence. No threshold for the
% number of photons is applied for the other window.
% By doing so, two coincidences are identified:
% (1) Coincidence of FRET bursts with selected PIE bursts
% (2) COincidence of PIE bursts with selected FRET bursts

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) COINCIDENCE FOR THRESHOLD FOR NUMBER OF PHOTONS JUST IN PIE WINDOW
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[t_PIE_start_coinc,t_PIE_end_coinc, t_PIE_start_coinc_FRET,t_PIE_end_coinc_FRET] = coinc(t_PIE_start_thres,PIEdat.t_FRET_start{file},t_PIE_end_thres,PIEdat.t_FRET_end{file});

N_PIE_thres(thr_loop) = length(t_PIE_start_thres);
N_PIE_coinc(thr_loop) = length(t_PIE_start_coinc);

idcoincPIE = ismember(t_PIE_start_thres,t_PIE_start_coinc);
idnocoincPIE = ~idcoincPIE;
idcoincPIE_FRET = ismember(PIEdat.t_FRET_start{file},t_PIE_start_coinc_FRET);   % FRET bursts to which PIE bursts were coincident

tdwell_PIE_thresh = (t_PIE_end_thres - t_PIE_start_thres)/1E6;
tdwell_PIE_coinc = (t_PIE_end_coinc - t_PIE_start_coinc)/1E6;
tdwell_PIE_nocoinc = tdwell_PIE_thresh(idnocoincPIE);
tdwell_PIE_coinc_FRET = (t_PIE_end_coinc_FRET - t_PIE_start_coinc_FRET)/1E6;

I_PIE_coinc = I_PIE_thresh(idcoincPIE);
I_PIE_nocoinc = I_PIE_thresh(idnocoincPIE);
I_PIE_coinc_FRET = PIEdat.I_FRET_FRET_DA{file}(idcoincPIE_FRET);

if isempty(tdwell_PIE_coinc)
    tdwell_PIE_coinc = double.empty(0,0);
end
if isempty(I_PIE_coinc)
    I_PIE_coinc = double.empty(0,0);
end

MB_PIE_thresh = I_PIE_thresh./tdwell_PIE_thresh;
MB_PIE_coinc = I_PIE_coinc./tdwell_PIE_coinc;
MB_PIE_nocoinc = I_PIE_nocoinc./tdwell_PIE_nocoinc;
MB_PIE_coinc_FRET = I_PIE_coinc_FRET./tdwell_PIE_coinc_FRET;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) COINCIDENCE FOR THRESHOLD FOR NUMBER OF PHOTONS JUST IN FRET WINDOW
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[t_FRET_start_coinc,t_FRET_end_coinc,t_FRET_start_coinc_PIE,t_FRET_end_coinc_PIE] = coinc(t_FRET_start_thres,PIEdat.t_PIE_start{file},t_FRET_end_thres,PIEdat.t_PIE_end{file});

N_FRET_thres(thr_loop) = length(t_FRET_start_thres);
N_FRET_coinc(thr_loop) = length(t_FRET_start_coinc);

idcoincFRET = ismember(t_FRET_start_thres,t_FRET_start_coinc);
idnocoincFRET = ~idcoincFRET;
idcoincFRET_PIE = ismember(PIEdat.t_PIE_start{file},t_FRET_start_coinc_PIE);   % FRET bursts to which PIE bursts were coincident

tdwell_FRET_thresh = (t_FRET_end_thres - t_FRET_start_thres)/1E6;
tdwell_FRET_coinc = (t_FRET_end_coinc - t_FRET_start_coinc)/1E6;
tdwell_FRET_nocoinc = tdwell_FRET_thresh(idnocoincFRET);
tdwell_FRET_coinc_PIE = (t_FRET_end_coinc_PIE - t_FRET_start_coinc_PIE)/1E6;

I_FRET_coinc = I_FRET_thresh(idcoincFRET);
I_FRET_nocoinc = I_FRET_thresh(idnocoincFRET);
I_FRET_coinc_PIE = PIEdat.I_PIE_PIE{file}(idcoincFRET_PIE);

if isempty(tdwell_FRET_coinc)
    tdwell_FRET_coinc = double.empty(0,0);
end
if isempty(I_FRET_coinc)
    I_FRET_coinc = double.empty(0,0);
end

MB_FRET_thresh = I_FRET_thresh./tdwell_FRET_thresh;
MB_FRET_coinc = I_FRET_coinc./tdwell_FRET_coinc;
MB_FRET_nocoinc = I_FRET_nocoinc./tdwell_FRET_nocoinc;
MB_FRET_coinc_PIE = I_FRET_coinc_PIE./tdwell_FRET_coinc_PIE;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate Coincidence parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

thr_ana(thr_loop,1) = thr_fraction;
thr_ana(thr_loop,2) = length(PIEdat.I_PIE_PIE{file});
thr_ana(thr_loop,3) = length(PIEdat.I_FRET_FRET_DA{file});
thr_ana(thr_loop,4) = N_PIE_thres(thr_loop);
thr_ana(thr_loop,5) = N_FRET_thres(thr_loop);
thr_ana(thr_loop,6) = N_PIE_coinc(thr_loop);
thr_ana(thr_loop,7) = N_FRET_coinc(thr_loop);
thr_ana(thr_loop,8) = N_PIE_coinc(thr_loop)/N_PIE_thres(thr_loop);
thr_ana(thr_loop,9) = N_FRET_coinc(thr_loop)/N_FRET_thres(thr_loop);
thr_ana(thr_loop,10) = mean(tdwell_PIE_thresh);
thr_ana(thr_loop,11) = mean(tdwell_PIE_coinc);
thr_ana(thr_loop,12) = mean(tdwell_PIE_nocoinc);
thr_ana(thr_loop,13) = mean(tdwell_PIE_coinc_FRET);
thr_ana(thr_loop,14) = mean(tdwell_FRET_thresh);
thr_ana(thr_loop,15) = mean(tdwell_FRET_coinc);
thr_ana(thr_loop,16) = mean(tdwell_FRET_nocoinc);
thr_ana(thr_loop,17) = mean(tdwell_FRET_coinc_PIE);
thr_ana(thr_loop,18) = mean(I_PIE_thresh);
thr_ana(thr_loop,19) = mean(I_PIE_coinc);
thr_ana(thr_loop,20) = mean(I_PIE_nocoinc);
thr_ana(thr_loop,21) = mean(I_PIE_coinc_FRET);
thr_ana(thr_loop,22) = mean(I_FRET_thresh);
thr_ana(thr_loop,23) = mean(I_FRET_coinc);
thr_ana(thr_loop,24) = mean(I_FRET_nocoinc);
thr_ana(thr_loop,25) = mean(I_FRET_coinc_PIE);
thr_ana(thr_loop,26) = mean(MB_PIE_thresh);
thr_ana(thr_loop,27) = mean(MB_PIE_coinc);
thr_ana(thr_loop,28) = mean(MB_PIE_nocoinc);
thr_ana(thr_loop,29) = mean(MB_PIE_coinc_FRET);
thr_ana(thr_loop,30) = mean(MB_FRET_thresh);
thr_ana(thr_loop,31) = mean(MB_FRET_coinc);
thr_ana(thr_loop,32) = mean(MB_FRET_nocoinc);
thr_ana(thr_loop,33) = mean(MB_FRET_coinc_PIE);

if ~thr_ana(thr_loop,6)==0
    thr_ana(thr_loop,34) = sqrt((1/thr_ana(thr_loop,6))+(1/thr_ana(thr_loop,4)))*thr_ana(thr_loop,8);
else
    thr_ana(thr_loop,34) = sqrt(((1/thr_ana(thr_loop,4)))*(1/thr_ana(thr_loop,4)));
end

if ~thr_ana(thr_loop,7)==0
    thr_ana(thr_loop,35) = sqrt((1/thr_ana(thr_loop,7))+(1/thr_ana(thr_loop,5)))*thr_ana(thr_loop,9);
else
    thr_ana(thr_loop,35) = sqrt(((1/thr_ana(thr_loop,5)))*(1/thr_ana(thr_loop,5)));
end
thr_ana(thr_loop,42) = PIEburstThreshold(thr_loop);
thr_ana(thr_loop,43) = FRETburstThreshold(thr_loop);

end

%% Chance coincidence Analysis

NPIE =  -log(1-(thr_ana(:,4).*thr_ana(:,10)./(PIEdat.measTime(file)/1E6)));
NFRET =  -log(1-(thr_ana(:,5).*thr_ana(:,14)./(PIEdat.measTime(file)/1E6)));
fchancePIE = 1-exp(-NFRET(1)*((thr_ana(:,10)/thr_ana(1,14))+1));
fchanceFRET = 1-exp(-NPIE(1)*((thr_ana(:,14)/thr_ana(1,10))+1));

thr_ana(:,36) = NPIE;
thr_ana(:,37) = NFRET;
thr_ana(:,38) = fchancePIE;
thr_ana(:,39) = fchanceFRET;
thr_ana(:,40) = (thr_ana(:,8)-fchancePIE(:))./(1-fchancePIE(:));
thr_ana(:,41) = (thr_ana(:,9)-fchanceFRET(:))./(1-fchanceFRET(:));

%% calculate optimal threshold

% coinc_PIE = N_PIE_coinc./N_PIE_thres;
% coinc_FRET = N_FRET_coinc./N_FRET_thres;
coinc_PIE = thr_ana(:,40);
coinc_FRET = thr_ana(:,41);
acc_coinc_PIE = coinc_PIE(end) - coinc_PIE;
acc_coinc_FRET = coinc_FRET(end) - coinc_FRET;
rel_acc_coinc_PIE = acc_coinc_PIE./coinc_PIE;
rel_acc_coinc_FRET = acc_coinc_FRET./coinc_FRET;
prec_coinc_PIE = abs(sqrt((1./N_PIE_coinc)+(1./N_PIE_thres)).*coinc_PIE);
prec_coinc_FRET = abs(sqrt((1./N_FRET_coinc)+(1./N_FRET_thres)).*coinc_FRET);
rel_prec_coinc_PIE = prec_coinc_PIE./coinc_PIE;
rel_prec_coinc_FRET = prec_coinc_FRET./coinc_FRET;

N_FRET_only = N_FRET_thres - N_FRET_coinc;
N_PIE_only = N_PIE_thres - N_PIE_coinc;
x_FRET_only = N_FRET_only./N_FRET_thres;
x_PIE_only = N_PIE_only./N_PIE_thres;
% sig_FRET_only = sqrt((1./N_FRET_only)+(1./N_FRET_thres)).*x_FRET_only;     % error on donor-only fraction
% sig_FRET_only(isnan(sig_FRET_only))=0;                                     % if X_D0=0 -> error=0
% sig_PIE_only = sqrt((1./N_PIE_only)+(1./N_PIE_thres)).*x_PIE_only;
% sig_PIE_only(isnan(sig_PIE_only))=0;                                       % if X_A0=0 -> error=0
% rel_sig_FRET_only = sig_FRET_only./x_FRET_only;                            % relative error on donor-only fraction (increases with increasing threshold)
% rel_sig_FRET_only(isnan(rel_sig_FRET_only))=1; 
% rel_sig_PIE_only = sig_PIE_only./x_PIE_only;
% rel_sig_PIE_only(isnan(rel_sig_PIE_only))=1; 
% delta_x_FRET_coinc = x_FRET_only - x_FRET_only(end);                       % difference to best guess for donor-only fraction (i.e.value for highest threshold) 
% delta_x_PIE_coinc = x_PIE_only - x_PIE_only(end);
% 
% if x_FRET_only(end)==0
%     impr_FRET = delta_x_FRET_coinc;
% else    
%     impr_FRET = delta_x_FRET_coinc./x_FRET_only;
% end 
% 
% if x_PIE_only(end)==0
%     impr_PIE = delta_x_PIE_coinc;
% else    
%     impr_PIE = delta_x_PIE_coinc./x_PIE_only;
% end 

zci = @(v) find(v(:).*circshift(v(:), [-1 0]) <= 0);                       % Returns Zero-Crossing Indices Of Argument Vector

ind_PIE = zci(rel_acc_coinc_PIE-rel_prec_coinc_PIE);
if isempty(ind_PIE)
    ind_PIE = length(rel_acc_coinc_PIE);
end                                                                         % Approximate Zero-Crossing Indices
ind_PIE_thr = min(ind_PIE);

ind_FRET = zci(rel_acc_coinc_FRET-rel_prec_coinc_FRET);                               % Approximate Zero-Crossing Indices
if isempty(ind_FRET)
    ind_FRET = length(rel_acc_coinc_FRET);
end    
ind_FRET_thr = min(ind_FRET);

%%%%%%%%%%%%%%%%%%%%%%
% ind_PIE_thr=200;
% ind_FRET_thr=200;
%%%%%%%%%%%%%%%%%%%%%%%

ind_FRET_opt = ind_FRET_thr;
ind_PIE_opt = ind_PIE_thr;

thr_PIE_rel = thr_ana(ind_PIE_thr,1);
thr_FRET_rel = thr_ana(ind_FRET_thr,1);
PIEdat.optthrPIE(file) = PIEdat.mean_I_PIE(file)*thr_PIE_rel;                   % generate handy variable name
PIEdat.optthrFRET(file) = PIEdat.mean_I_FRET(file)*thr_FRET_rel;                   % generate handy variable name
PIEdat.optthrPIErel(file) = thr_PIE_rel;                   % generate handy variable name
PIEdat.optthrFRETrel(file) = thr_FRET_rel;                   % generate handy variable name

PIEdat.tccd.NPIEsel_opt(file) = N_PIE_thres(ind_PIE_thr);
PIEdat.tccd.NFRETsel_opt(file) = N_FRET_thres(ind_FRET_thr);
PIEdat.tccd.NPIEcoinc_opt(file) = N_PIE_coinc(ind_PIE_thr);
PIEdat.tccd.NFRETcoinc_opt(file) = N_FRET_coinc(ind_FRET_thr);
PIEdat.tccd.noPIEcoinc_opt(file) = x_PIE_only(ind_PIE_thr);
PIEdat.tccd.noFRETcoinc_opt(file) = x_FRET_only(ind_FRET_thr);
PIEdat.tccd.precPIEcoinc_opt(file) = prec_coinc_PIE(ind_PIE_thr);
PIEdat.tccd.precFRETcoinc_opt(file) = prec_coinc_FRET(ind_FRET_thr);
PIEdat.tccd.frac_PIEsel_opt(file) = PIEdat.tccd.NPIEsel_opt(file)/thr_ana(1,2);
PIEdat.tccd.frac_FRETsel_opt(file) = PIEdat.tccd.NFRETsel_opt(file)/thr_ana(1,3);

fig_optthres_PIE = figure();
plot(thr_ana(:,1),rel_prec_coinc_PIE,'r', 'LineWidth', 2)
hold on
plot(thr_ana(:,1), rel_acc_coinc_PIE,'b', 'LineWidth',2)
plot(thr_PIE_rel,rel_acc_coinc_PIE(ind_PIE_thr),'Color',[0 0.5 0],'MarkerFaceColor',[0 0.5 0],'MarkerSize',15,'LineWidth',3,'Marker','diamond')
text(0.8*thr_PIE_rel, 2*rel_acc_coinc_PIE(ind_PIE_thr),['threshold_{opt} = ', num2str(thr_PIE_rel,  3)],'FontSize',12,'EdgeColor','black');
xlabel('threshold / <#\gamma>')
legend('rel. precision x_{A0}', 'rel. accuracy x_{A0}')
set(gca,'FontSize',16, 'FontWeight','bold')

if ~exist([PIEdat.defaultdirectory 'figures\'],'dir')
    mkdir([PIEdat.defaultdirectory 'figures\']);
end

hgsave(fig_optthres_PIE, strcat(PIEdat.defaultdirectory, 'figures\', PIEdat.filenameShort{file},'_opt_thres_PIE.fig'));
close(fig_optthres_PIE);

fig_optthres_FRET = figure();
plot(thr_ana(:,1),rel_prec_coinc_FRET,'r', 'LineWidth', 2)
hold on
plot(thr_ana(:,1), rel_acc_coinc_FRET,'b', 'LineWidth',2)
plot(thr_FRET_rel,rel_acc_coinc_FRET(ind_FRET_thr),'Color',[0 0.5 0],'MarkerFaceColor',[0 0.5 0],'MarkerSize',15,'LineWidth',3,'Marker','diamond')
text(0.8*thr_FRET_rel, 2*rel_acc_coinc_FRET(ind_FRET_thr),['threshold_{opt} = ', num2str(thr_FRET_rel,  3)],'FontSize',12,'EdgeColor','black');
xlabel('threshold / <#\gamma>')
legend('rel. precision x_{D0}', 'rel. accuracy x_{D0}')
set(gca,'FontSize',16, 'FontWeight','bold')
hgsave(fig_optthres_FRET, strcat(PIEdat.defaultdirectory, 'figures\',PIEdat.filenameShort{file},'_opt_thres_FRET.fig'));
close(fig_optthres_FRET);

clear fig_optthres_PIE fig_optthres_FRET

%% fit coincidence curves
coincfunc = 'b-(a*exp(-x/c))';
startPoints_PIE = [coinc_PIE(ind_PIE_thr)-coinc_PIE(1) coinc_PIE(ind_PIE_thr) thr_PIE_rel];
options = fitoptions(coincfunc);
options.StartPoint = startPoints_PIE;
%options.Exclude = thr_ana(:,1)>2.5;
options.Lower = [0 0 0];
options.Upper = [1 1 thr_ana(end,1)];
options.Weights = 1./prec_coinc_PIE;
fcoinc_PIE = fit(thr_ana(:,1),coinc_PIE,coincfunc,options);
ci_PIE = confint(fcoinc_PIE);

startPoints_FRET = [coinc_FRET(ind_FRET_thr)-coinc_FRET(1) coinc_FRET(ind_FRET_thr) thr_FRET_rel];
options.StartPoint = startPoints_FRET;
options.Weights = 1./prec_coinc_FRET;
fcoinc_FRET = fit(thr_ana(:,1),coinc_FRET,coincfunc, options);
ci_FRET = confint(fcoinc_FRET);

PIEdat.tccd.PIEcoinc_fit(file) = fcoinc_PIE.b;
PIEdat.tccd.errPIEcoinc_fit(file) = ci_PIE(2,2)-ci_PIE(1,2);
PIEdat.tccd.FRETcoinc_fit(file) = fcoinc_FRET.b;
PIEdat.tccd.errFRETcoinc_fit(file) = ci_FRET(2,2)-ci_FRET(1,2);

fig_coincfit = figure();
plot(thr_ana(:,1), coinc_PIE, 'Color', [1 0 0], 'LineWidth', 2)
hold on
plot(fcoinc_PIE)
plot(thr_ana(:,1), coinc_FRET, 'Color', [0 0 1], 'LineWidth', 2)
plot(fcoinc_FRET)
xlabel('threshold #\gamma / <#\gamma>')
ylabel('fraction of coincident bursts')
legend('red', 'red fit', 'blue', 'blue fit')
hgsave(fig_coincfit, strcat(PIEdat.defaultdirectory, 'figures\',PIEdat.filenameShort{file},'_coincfit.fig'));
close(fig_coincfit);

%% calculate coincidence parameter
%coinc_PIE = N_PIE_coinc./N_PIE_thres;
%coinc_FRET = N_FRET_coinc./N_FRET_thres;
frac_sel_bursts_PIE = N_PIE_thres ./ thr_ana(:,2);              % fraction of bursts that exceed above threshold in PIE channel
frac_sel_bursts_FRET = N_FRET_thres ./ thr_ana(:,3);       % fraction of bursts that exceed above threshold in FRET channel

%pos_mean = ceil((N_loops+1)/frac_end);                                     % index in array that belongs to threhold = mean number of photons
N_PIE_coinc_mean = N_PIE_coinc(ind_PIE_thr);
N_FRET_coinc_mean = N_FRET_coinc(ind_FRET_thr);
if N_PIE_coinc_mean > N_FRET_coinc_mean
    flag_more_coinc_PIE = true;
else
    flag_more_coinc_PIE = false;
end    

%% Plot distribution of photons/burst

% Generate and save distribution plot for # photons

x_photons_distr_PIE = -0.5:1:max(PIEdat.I_PIE_PIE{file})+0.5;
x_photons_distr_FRET = -0.5:1:max(PIEdat.I_FRET_FRET_DA{file})+0.5;
fig_hist_phot = figure();   
axes('position',[0.15 0.65 0.8 0.35])
h_PIE = histogram(PIEdat.I_PIE_PIE{file}, x_photons_distr_PIE, 'FaceColor', 'red');
line([PIEdat.optthrPIE(file) PIEdat.optthrPIE(file)], [0,  max(h_PIE.Values)], 'Color', [0 0 0], 'LineWidth', 2);
text(0.9*PIEdat.optthrPIE(file), 1.02*max(h_PIE.Values),'opt. threshold','FontSize',12);
text(1.5*PIEdat.optthrPIE(file), 0.9*max(h_PIE.Values),['threshold \gamma = ', num2str(PIEdat.optthrPIE(file),  3)],'FontSize',14,'EdgeColor','black');
text(1.5*PIEdat.optthrPIE(file), 0.75*max(h_PIE.Values),['<\gamma> = ', num2str(PIEdat.mean_I_PIE(file),  3)],'FontSize',14,'EdgeColor','black');
text(1.5*PIEdat.optthrPIE(file), 0.6*max(h_PIE.Values),['<selected bursts> = ', num2str(frac_sel_bursts_PIE(ind_PIE_thr)*100,3), '%'],'FontSize',14,'EdgeColor','black');
xlabel('# photons','FontSize',12, 'FontWeight','bold')
ylabel('occurence','FontSize',12, 'FontWeight','bold')
xlim([-10 max(PIEdat.I_PIE_PIE{file})+10])
ylim([0 max(h_PIE.Values)+10])
set(gca, 'FontWeight', 'bold', 'FontSize', 14)
legend('PIE')
axes('position',[0.15 0.15 0.8 0.35])
h_FRET = histogram(PIEdat.I_FRET_FRET_DA{file}, x_photons_distr_FRET, 'FaceColor', 'blue');
line([PIEdat.optthrFRET(file) PIEdat.optthrFRET(file)], [0,  max(h_FRET.Values)], 'Color', [0 0 0], 'LineWidth', 2);
text(0.9*PIEdat.optthrFRET(file), 1.02*max(h_FRET.Values),'opt.threshold','FontSize',12);
text(1.5*PIEdat.optthrFRET(file), 0.9*max(h_FRET.Values),['threshold \gamma = ', num2str(PIEdat.optthrFRET(file),  3)],'FontSize',14,'EdgeColor','black');
text(1.5*PIEdat.optthrFRET(file), 0.75*max(h_FRET.Values),['<\gamma> = ', num2str(PIEdat.mean_I_FRET(file),  3)],'FontSize',14,'EdgeColor','black');
text(1.5*PIEdat.optthrFRET(file), 0.6*max(h_FRET.Values),['<selected bursts> = ', num2str(frac_sel_bursts_FRET(ind_FRET_thr)*100,3), '%'],'FontSize',14,'EdgeColor','black');
xlabel('# photons','FontSize',12, 'FontWeight','bold')
ylabel('occurence','FontSize',12, 'FontWeight','bold')
xlim([-10 max(PIEdat.I_FRET_FRET_DA{file})+10])
ylim([0 max(h_FRET.Values)+10])
set(gca, 'FontWeight', 'bold', 'FontSize', 14)
legend('FRET')
hgsave(fig_hist_phot, strcat(PIEdat.defaultdirectory, 'figures\',PIEdat.filenameShort{file},'_hist_phot.fig'));
close(fig_hist_phot);

%Temporary start
x_photons_distr_PIE_tmp = 0:1:max(PIEdat.I_PIE_PIE{file});
x_photons_distr_FRET_tmp = 0:1:max(PIEdat.I_FRET_FRET_DA{file});
clear bPIE bFRET
bPIE(:,1)=x_photons_distr_PIE_tmp;
bPIE(:,2)= (hist(PIEdat.I_FRET_FRET_DA{file}, x_photons_distr_PIE_tmp))';
save('phot_hist_PIE.dat','bPIE','-ascii');
bFRET(:,1)=x_photons_distr_FRET_tmp;
bFRET(:,2)= (hist(PIEdat.I_FRET_FRET_DA{file}, x_photons_distr_FRET_tmp))';
save('phot_hist_FRET.dat','bFRET','-ascii');
%Temporary end

clear fig_hist_phot h_PIE h_FRET PIEdat.optthrPIE PIEdat.optthrFRET x_photons_distr_PIE x_photons_distr_FRET 


%% Plot dependence of coincidence parameter on number of photons threshold

axes(handles.AX_CoincThres);
cla;
plot(thr_ana(:,1), coinc_PIE, 'Color', [1 0 0], 'LineWidth', 2)
hold on
plot(thr_ana(:,1), thr_ana(:,8), 'Color', [1 0 0], 'LineWidth', 1, 'LineStyle', '--')
plot(thr_ana(:,1), coinc_FRET, 'Color', [0 0 1], 'LineWidth', 2)
plot(thr_ana(:,1), thr_ana(:,9), 'Color', [0 0 1], 'LineWidth', 1, 'LineStyle', '--')
line([thr_PIE_rel thr_PIE_rel], [min(min(coinc_PIE),min(coinc_FRET)) 1], 'Color', [1 0 0], 'LineWidth', 1);
line([thr_FRET_rel thr_FRET_rel], [min(min(coinc_PIE),min(coinc_FRET)) 1], 'Color', [0 0 1], 'LineWidth', 1);
xlabel('threshold #\gamma / <#\gamma>')
ylabel('fraction of coincident bursts')
text(1.1*thr_PIE_rel, 0.8*max(coinc_PIE),['thres PIE = ', num2str(thr_PIE_rel,3)],'FontSize',10,'EdgeColor','black');
text(1.1*thr_FRET_rel, 0.8*max(coinc_FRET),['thres FRET = ', num2str(thr_FRET_rel,3)],'FontSize',10,'EdgeColor','black');
%set(handles.AX_CoincThres, 'FontWeight', 'bold', 'FontSize', 12)
legend('PIE cor', 'PIE raw', 'FRET cor', 'FRET raw')

FigCoincThres = figure;
set(gcf,'Visible','on','PaperPositionMode','auto');
copyobj(handles.AX_CoincThres, FigCoincThres);
hgsave(FigCoincThres, [PIEdat.defaultdirectory 'figures\' PIEdat.filenameShort{file} '_coinc_thres.fig']);
close(FigCoincThres);

% Generate extrapolated line of coinc bursts vs. # photons threshold
% thres = 1:0.1*(frac_end-1)/N_loops:frac_end; 
% coinc_burst_int(:,1) = thres;
% if flag_more_coinc_PIE
%     coinc_data = thr_ana(:,6);
% else    
%     coinc_data = thr_ana(:,7);
% end    
% 
% coinc_burst_int(:,2) = interp1(thr_ana(:,1),coinc_data, thres,'spline');

% Calculation of the intersection between coincident bursts

if flag_more_coinc_PIE
    if thr_ana(end,6)>thr_ana(ind_FRET_thr,7)
        ind_FRET_thr = min(zci(thr_ana(:,7)-thr_ana(end,6)));
        xmin=thr_loop;
        disp('Number of coincident FRET bursts can not further be decreased. Reset opt. PIE burst threshold to lower value.')
    else
        delta = abs(thr_ana(:,6)-thr_ana(ind_FRET_thr,7));
        [~, xmin] = min(delta);
    end
    thrphotrelPIE(file)=thr_ana(xmin,1);
    thrphotrelFRET(file)=thr_ana(ind_FRET_thr,1);
else
    if thr_ana(end,7)>thr_ana(ind_PIE_thr,6)
        ind_PIE_thr = min(zci(thr_ana(:,6)-thr_ana(end,7)));
        xmin=thr_loop;
        disp('Number of coincident PIE bursts can not further be decrased. Reset opt. FRET burst threshold to lower value.')
    else     
        delta = abs(thr_ana(:,7)-thr_ana(ind_PIE_thr,6));
    	[~, xmin] = min(delta);
    end
    thrphotrelPIE(file)=thr_ana(ind_PIE_thr,1);
    thrphotrelFRET(file)=thr_ana(xmin,1);
end

PIEdat.thrphotPIE(file) = PIEdat.mean_I_PIE(file)*thrphotrelPIE(file);                  
PIEdat.thrphotFRET(file) = PIEdat.mean_I_FRET(file)*thrphotrelFRET(file);
set(handles.ET_PIEBurstThresh, 'String', num2str(PIEdat.thrphotPIE(file),3));
set(handles.ET_FRETBurstThresh, 'String', num2str(PIEdat.thrphotFRET(file),3));


%% Plot decrease of bursts in dependence of threshold

fig_numcoincbursts = figure();   
plot(thr_ana(:,1), thr_ana(:,6), '-r');
hold on
plot(thr_ana(:,1), thr_ana(:,7), '-b');
if flag_more_coinc_PIE
    thresh = ones(1,length(thr_ana(:,1))).*thr_ana(ind_FRET_thr,7);
    plot(thr_ana(:,1),thresh,'--b', 'LineWidth',2);
    plot(thr_PIE_rel,thr_ana(ind_PIE_opt,6),'Color',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',15,'LineStyle','none','Marker','o')
    plot(thrphotrelPIE(file),thr_ana(xmin,6),'Color',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',15,'LineStyle','none','Marker','diamond')
    plot(thrphotrelFRET(file),thr_ana(ind_FRET_thr,7),'Color',[0 0 1],'MarkerFaceColor',[0 0 1],'MarkerSize',15,'LineStyle','none','Marker','diamond')
    legend('coinc PIE', 'coinc FRET', 'opt. threshold FRET', 'opt. threshold PIE','global thrshold PIE','global threshold FRET')
else    
    thresh = ones(1,length(thr_ana(:,1))).*thr_ana(ind_PIE_thr,6);
    plot(thr_ana(:,1),thresh,'--r', 'LineWidth',2);
    plot(thr_FRET_rel,thr_ana(ind_FRET_opt,7),'Color',[0 0 1],'MarkerFaceColor',[0 0 1],'MarkerSize',15,'LineStyle','none','Marker','o')
    plot(thrphotrelPIE(file),thr_ana(ind_PIE_thr,6),'Color',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',15,'LineStyle','none','Marker','diamond')
    plot(thrphotrelFRET(file),thr_ana(xmin,7),'Color',[0 0 1],'MarkerFaceColor',[0 0 1],'MarkerSize',15,'LineStyle','none','Marker','diamond')
    legend('coinc PIE', 'coinc FRET', 'opt. threshold PIE','opt. threshold FRET','global threshold PIE','global threshold FRET')
end

xlabel('threshold / <\gamma>')
ylabel('number of selected bursts')
hgsave(fig_numcoincbursts, strcat(PIEdat.defaultdirectory, 'figures\',PIEdat.filenameShort{file},'_numcoincburst.fig'));
close(fig_numcoincbursts);


%% Calculate global stoichiometry values
% Consider cases seperately
% 1. more bursts in PIE
% 2. more bursts in FRET
axes(handles.AX_Coincidence);                                               % set current axes for histogram
cla
if flag_more_coinc_PIE
    PIEdat.tccd.NAsel{file} = thr_ana(xmin,4);
    PIEdat.tccd.NAcoinc{file} = thr_ana(xmin,6);
    PIEdat.tccd.NDsel{file} = thr_ana(ind_FRET_thr,5);
    PIEdat.tccd.NDcoinc{file} = thr_ana(ind_FRET_thr,7);
    
    plot(thr_ana(:,1), thr_ana(:,6), '-r');
    hold on
    thresh = ones(1,length(thr_ana(:,1))).*thr_ana(ind_FRET_thr,7);
    plot(thr_ana(:,1),thresh,'--b', 'LineWidth',2);
    %ylim([0.9*thr_ana(end,6), 1.1*thr_ana(ind_FRET_thr,6)])
    text(0.7*thr_ana(end,1), 0.8*thr_ana(ind_FRET_thr,6),['opt. thres PIE = ', num2str(thr_ana(xmin,1),3)],'FontSize',10,'EdgeColor','black');
    legend('coinc PIE', 'reference FRET')
else
    
    PIEdat.tccd.NDsel{file} = thr_ana(xmin,5);
    PIEdat.tccd.NDcoinc{file} = thr_ana(xmin,7);
    PIEdat.tccd.NAsel{file} = thr_ana(ind_PIE_thr,4);
    PIEdat.tccd.NAcoinc{file} = thr_ana(ind_PIE_thr,6);
    
    plot(thr_ana(:,1), thr_ana(:,7), '-b');
    hold on
    thresh = ones(1,length(thr_ana(:,1))).*thr_ana(ind_PIE_thr,6);
    plot(thr_ana(:,1),thresh,'--r', 'LineWidth',2);
    %ylim([0.9*thr_ana(end,7), 1.1*thr_ana(ind_PIE_thr,7)])
    text(0.7*thr_ana(end,1), 0.8*thr_ana(ind_PIE_thr,7),['opt. thres PIE = ', num2str(thr_ana(xmin,1),3)],'FontSize',10,'EdgeColor','black');
    legend('coinc FRET', 'reference PIE')
end
xlabel(handles.AX_Coincidence,'threshold # \gamma / <#\gamma>')
ylabel(handles.AX_MolecularBrightnessPIE,'# of coincident bursts')
FigCoinc = figure;
set(gcf,'Visible','on','PaperPositionMode','auto');
copyobj(handles.AX_Coincidence, FigCoinc);
hgsave(FigCoinc, [PIEdat.defaultdirectory 'figures\' PIEdat.filenameShort{file} '_coincidence.fig']);
close(FigCoinc);


if ~exist([PIEdat.defaultdirectory 'stoichiometry results\'],'dir')
    mkdir([PIEdat.defaultdirectory 'stoichiometry results\']);
end
name_thr_ana = [PIEdat.defaultdirectory 'stoichiometry results\' PIEdat.filenameShort{file} '_threshold_analysis.mat'];
save(name_thr_ana,'thr_ana');
save([PIEdat.defaultdirectory 'stoichiometry results\' PIEdat.filenameShort{file} '_threshold_analysis.dat'],'thr_ana','-ascii');

% Calculate the stochiometry fractions (global)
PIEdat.tccd.NAall{file} = thr_ana(1,2);
PIEdat.tccd.NDall{file} = thr_ana(1,3);
if abs(PIEdat.tccd.NAcoinc{file}-PIEdat.tccd.NDcoinc{file}) < 0.1*max(PIEdat.tccd.NAcoinc{file},PIEdat.tccd.NAcoinc{file})
    PIEdat.tccd.NDA{file} = round(mean([PIEdat.tccd.NAcoinc{file},PIEdat.tccd.NDcoinc{file}]));
else
    disp('NUMBER OF COINCIDENT BURSTS NOT CONSISTENT! CHECK RESULTS!!!!')
    PIEdat.tccd.NDA{file} = round(mean([PIEdat.tccd.NAcoinc{file},PIEdat.tccd.NDcoinc{file}]));
end    

PIEdat.tccd.NA0{file} = PIEdat.tccd.NAsel{file} - PIEdat.tccd.NDA{file};
PIEdat.tccd.ND0{file} = PIEdat.tccd.NDsel{file} - PIEdat.tccd.NDA{file};
PIEdat.tccd.Ntot{file} = PIEdat.tccd.NDA{file} + PIEdat.tccd.NA0{file} + PIEdat.tccd.ND0{file};
PIEdat.tccd.xA0{file} = PIEdat.tccd.NA0{file}/PIEdat.tccd.Ntot{file};
PIEdat.tccd.xD0{file} = PIEdat.tccd.ND0{file}/PIEdat.tccd.Ntot{file};
PIEdat.tccd.xDA{file} = PIEdat.tccd.NDA{file}/PIEdat.tccd.Ntot{file};

PIEdat.tccd.xA0_err{file} = sqrt((1./PIEdat.tccd.NA0{file})+(1./PIEdat.tccd.Ntot{file})).*PIEdat.tccd.xA0{file};
PIEdat.tccd.xD0_err{file} = sqrt((1./PIEdat.tccd.ND0{file})+(1./PIEdat.tccd.Ntot{file})).*PIEdat.tccd.xD0{file};
PIEdat.tccd.xDA_err{file} = sqrt((1./PIEdat.tccd.NDA{file})+(1./PIEdat.tccd.Ntot{file})).*PIEdat.tccd.xDA{file};

% Write the results to static text fields
set(handles.ST_NumPIEbursts, 'String', ['PIE bursts: ', num2str(PIEdat.tccd.NAall{file}), ' / ', num2str(PIEdat.tccd.NAsel{file}), ' / ', num2str(PIEdat.tccd.NAcoinc{file})]);
set(handles.ST_NumFRETbursts, 'String', ['FRET bursts: ', num2str(PIEdat.tccd.NDall{file}), ' / ', num2str(PIEdat.tccd.NDsel{file}), ' / ', num2str(PIEdat.tccd.NDcoinc{file})]);
set(handles.ST_NumBurstsSummary, 'String', ['ND0 = ',num2str(PIEdat.tccd.ND0{file}), '  /  NA0 = ', num2str(PIEdat.tccd.NA0{file}),'  /  NDA = ', num2str(PIEdat.tccd.NDA{file}), '  /  Ntot = ', num2str(PIEdat.tccd.Ntot{file})]);
set(handles.ST_Stochiometry, 'String', ['xA0 = ',num2str(PIEdat.tccd.xA0{file},3), '     xD0 = ', num2str(PIEdat.tccd.xD0{file},3),'    xDA = ', num2str(PIEdat.tccd.xDA{file},3)]);

% plot 'burst marker' to IPD traces
if file==1
    % just plot the first 10s
    dispPIE_thres = length(t_PIE_start_thres(t_PIE_start_thres < 10E9));
    dispDA_thres = length(t_FRET_start_thres(t_FRET_start_thres < 10E9));
    dispPIE_coinc = length(t_PIE_start_coinc(t_PIE_start_coinc < 10E9));
    dispDA_coinc = length(t_FRET_start_coinc(t_FRET_start_coinc < 10E9));
    
    axes(handles.AX_IPDtrace);
    hold on
    
    for m = 1:dispPIE_thres
        f1 = find(PIEdat.t_PIE_A{file}>=t_PIE_start_thres(m) & PIEdat.t_PIE_A{file}<=t_PIE_end_thres(m));
        PIE_burst_marker = ones(1,length(f1)).*0.95*PIEdat.l_IPDburstThreshold_PIE_A(1);
        plot(PIEdat.t_PIE_A{file}(f1(1):f1(end)).*10^-9, PIE_burst_marker,'r -','LineWidth',20);
        hold on;
    end

    for n = 1:dispDA_thres
        f2 = find(PIEdat.t_FRET_DA{file}>=t_FRET_start_thres(n) & PIEdat.t_FRET_DA{file}<=t_FRET_end_thres(n));
        DA_burst_marker = ones(1,length(f2)).*1.05*PIEdat.l_IPDburstThreshold_FRET_DA(1);
        plot(handles.AX_IPDtrace, PIEdat.t_FRET_DA{file}(f2(1):f2(end)).*10^-9, DA_burst_marker,'g -','LineWidth',20);
    end

    for p = 1:dispPIE_coinc
        f3 = find(PIEdat.t_PIE_A{file}>=t_PIE_start_coinc(p) & PIEdat.t_PIE_A{file}<=t_PIE_end_coinc(p));
        PIE_coinc_burst_marker = ones(1,length(f3)).*PIEdat.l_IPDburstThreshold_PIE_A(1);
        plot(handles.AX_IPDtrace, PIEdat.t_PIE_A{file}(f3(1):f3(end)).*10^-9, PIE_coinc_burst_marker,'k -','LineWidth',20);
    end

    for q = 1:dispDA_coinc
        f4 = find(PIEdat.t_FRET_DA{file}>=t_FRET_start_coinc(q) & PIEdat.t_FRET_DA{file}<=t_FRET_end_coinc(q));
        DA_coinc_burst_marker = ones(1,length(f4)).*PIEdat.l_IPDburstThreshold_FRET_DA(1);
        plot(handles.AX_IPDtrace, PIEdat.t_FRET_DA{file}(f4(1):f4(end)).*10^-9, DA_coinc_burst_marker,'k -','LineWidth',20);
    end

end

guidata(hObject, handles);                                                 % update handles structure
waitbar(file/PIEdat.l_fn, wbarh);

end

close(wbarh); 
disp('-------------------------------------------------')