function [t_sel_start_coinc, t_sel_end_coinc, t_ref_start_coinc, t_ref_end_coinc] = coinc(t_sel_start,t_ref_start,t_sel_end,t_ref_end)

% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (BTCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%COINC          Calculate coincidence between bursts in 2 channels
%               The coincidence from selected bursts (sel) to reference
%               bursts (ref) is calculated.
%               The coincident bursts time tags of sel (output) are always 
%               a subset of the input bursts time tags of sel. 
% Inputs:       t_sel_start         start times of selected bursts (ns)
%               t_ref_start         start times of reference bursts (ns)
%               t_sel_end           end times of selected bursts (ns)
%               t_ref_end           end times of reference bursts (ns)
% Outputs:      t_sel_start_coinc   start times of coincident selected bursts (ns)
%               t_sel_end_coinc     end times of coincident selected bursts (ns)
%   


% merge starting and ending times of both channels in one vector
allStartEnd = vertcat(t_sel_start,t_ref_start,t_sel_end,t_ref_end);
allStartEnd = sort(allStartEnd);

% search positions of starting and ending times in this vector
posselstart = histc(t_sel_start,allStartEnd);                              % binary vector of length(allStartEnd) that marks the positions of 't_sel_start' with a '1'
posrefstart = histc(t_ref_start,allStartEnd);                              % binary vector of length(allStartEnd) that marks the positions of 't_ref_start' with a '1'
posselend = histc(t_sel_end,allStartEnd);                                  % binary vector of length(allStartEnd) that marks the positions of 't_sel_end' with a '1'
posrefend = histc(t_ref_end,allStartEnd);                                  % binary vector of length(allStartEnd) that marks the positions of 't_ref_end' with a '1'

if isrow(posselstart)
    posselstart=posselstart';
end    
              
if isrow(posselend)
    posselend=posselend';
end  

if isrow(posrefstart)
    posrefstart=posrefstart';
end    
              
if isrow(posrefend)
    posrefend=posrefend';
end 

% encode the positions with arbitrary number (start=positive; end=negative)
posrefstart = posrefstart*7;
posselend = posselend*(-1);
posrefend = posrefend*(-7);

% sum up all this 'position marker'
posall = posselstart + posrefstart + posselend + posrefend;

% initialize auxiliary variables 
sum_tot = 0;                                                               
burstmark_start = ones(length(posall),1);
burstmark_end = ones(length(posall),1);

% coincidence is identified by cumulative sum (sum_tot) and sum of 2 
% following positions (sum_pos)
for n = 1:length(posall)-1
    sum_pos = posall(n) + posall(n+1);
    if sum_tot == 0 && sum_pos==0
        burstmark_start(n) = 0;
        burstmark_end(n+1) = 0;
    end
    sum_tot = sum_tot + posall(n);
end

% identified burst positions are applied to burst macro time vector
burstmark = burstmark_start & burstmark_end;                               % use logical 'and' to get binary mask
coinc_bursts = allStartEnd.*burstmark;                                     % select burst start and end times
coinc_bursts(coinc_bursts==0) = [];                                        % delete unselected entries
t_sel_start_coinc = intersect(coinc_bursts,t_sel_start);                   % get start times for coincidence bursts
t_sel_end_coinc = intersect(coinc_bursts,t_sel_end);                       % get end times for coincidence bursts
t_ref_start_coinc = intersect(coinc_bursts,t_ref_start);
t_ref_end_coinc = intersect(coinc_bursts,t_ref_end);


end