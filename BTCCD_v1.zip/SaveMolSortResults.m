function SaveMolSortResults(hObject, eventdata, handles)

% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (TCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

global PIEdat

%if ( isempty(PIEdat.coincidence.xDA))
%    errordlg('Calculate burst coordinates before saving','Bad Input','modal')
%    return
%end

% if PIEdat.l_fn==1
%         [filename, pathname] = uiputfile([PIEdat.defaultdirectory PIEdat.filenameShort{1} '_results.mat'],'Save results for stochiometry');
%         if isequal(filename,0) || isequal(pathname,0)
%             % User selected Cancel
%             return
%         end
% end

wbarh = waitbar(0,'Saving Results and Figures...');
disp(['Saving results for ' num2str(PIEdat.l_fn) ' file(s) ...']);

% initialize variables
if PIEdat.l_fn>1 
    Nbursts = zeros(PIEdat.l_fn,3);
end 

for file = 1:PIEdat.l_fn
    
    % save IPD histograms
    if ~exist([PIEdat.defaultdirectory 'IPD\'],'dir')
        mkdir([PIEdat.defaultdirectory 'IPD\']);
    end
    
    file_PIE = [PIEdat.defaultdirectory 'IPD\' PIEdat.filenameShort{file} '_IPD_PIE_A.dat'];
    file_D = [PIEdat.defaultdirectory 'IPD\' PIEdat.filenameShort{file} '_IPD_FRET_D.dat'];
    file_A = [PIEdat.defaultdirectory 'IPD\' PIEdat.filenameShort{file} '_IPD_FRET_A.dat'];
    file_DA = [PIEdat.defaultdirectory 'IPD\' PIEdat.filenameShort{file} '_IPD_FRET_DA.dat'];
    
    IPD_hist_PIE(:,1) = PIEdat.x_IPD_distr';
    IPD_hist_D(:,1) = PIEdat.x_IPD_distr';
    IPD_hist_A(:,1) = PIEdat.x_IPD_distr';
    IPD_hist_DA(:,1) = PIEdat.x_IPD_distr';
    IPD_hist_PIE(:,2) = PIEdat.hist_IPD_PIE{file}';
    IPD_hist_D(:,2) = PIEdat.hist_IPD_D{file}';
    IPD_hist_A(:,2) = PIEdat.hist_IPD_A{file}';
    IPD_hist_DA(:,2) = PIEdat.hist_IPD_DA{file}';
    
    save(file_PIE,'IPD_hist_PIE', '-ascii', '-tabs');
    save(file_D, 'IPD_hist_D', '-ascii', '-tabs');
    save(file_A, 'IPD_hist_A', '-ascii', '-tabs');
    save(file_DA, 'IPD_hist_DA', '-ascii', '-tabs');
    
    
    % use structure M for gathering the objects to save
    % parameter
    M.parameter.filename = PIEdat.filenameShort{file};
    M.parameter.donorChannel = PIEdat.donor_chan;
    M.parameter.acceptorChannel = PIEdat.acceptor_chan;
    M.parameter.StartWindowFRET = PIEdat.dt_start_window_FRET;
    M.parameter.EndWindowFRET = PIEdat.dt_end_window_FRET;
    M.parameter.StartWindowPIE = PIEdat.dt_start_window_PIE;
    M.parameter.EndWindowPIE = PIEdat.dt_end_window_PIE;
    M.parameter.smoothingFRET = PIEdat.mDA;
    M.parameter.smoothingPIE = PIEdat.mPIE;
    M.parameter.IPDthresholdPIE = PIEdat.IPDburstThreshold_PIE_A(file);                                     
    M.parameter.IPDthresholdFRET = PIEdat.IPDburstThreshold_FRET_DA(file);
    M.parameter.bg_IPD_PIE = PIEdat.bg_IPD_PIE(file);                                     
    M.parameter.bg_IPD_FRET = PIEdat.bg_IPD_DA(file);
    M.parameter.bg_countrate_FRET_DA = PIEdat.bg_FRET_DA(file);
    M.parameter.bg_countrate_PIE_A = PIEdat.bg_PIE_A(file);
    
    if isfield(PIEdat,'meanPhotPIE')
        M.parameter.meanPhotPIE = PIEdat.mean_I_PIE(file);
        M.parameter.meanPhotFRET = PIEdat.mean_I_FRET(file);
    end 
    
    if isfield(PIEdat,'E_FRET')
        M.parameter.FRETeff_allbursts = mean(PIEdat.E_FRET);
        M.parameter.FRETeff_DA = mean(PIEdat.E_FRETeff);
    end 
    
    M.parameter.FRET_threshold_DA = PIEdat.FRET_thresholdDA;
    M.parameter.crosstalk = PIEdat.alpha;
    M.parameter.directAcceptorExcitation = PIEdat.directAexc;
    M.parameter.detectionEfficiency = PIEdat.gamma;
    M.parameter.meanDwelltimePIE = PIEdat.meanBurstWidthPIE{file};
    M.parameter.meanDwelltimeFRET = PIEdat.meanBurstWidthFRET{file};
    M.parameter.stdDwelltimePIE = PIEdat.stdBurstWidthPIE{file};
    M.parameter.stdDwelltimeFRET = PIEdat.stdBurstWidthFRET{file};
    M.parameter.semDwelltimePIE = PIEdat.semBurstWidthPIE{file};
    M.parameter.semDwelltimeFRET = PIEdat.semBurstWidthFRET{file};
    M.parameter.meanMB_PIE = PIEdat.MB_PIE_mean{file};
    M.parameter.meanMB_FRET = PIEdat.MB_FRET_mean{file};
    M.parameter.stdMB_PIE = PIEdat.MB_PIE_std{file};
    M.parameter.stdMB_FRET = PIEdat.MB_FRET_std{file};
    M.parameter.semMB_PIE = PIEdat.MB_PIE_sem{file};
    M.parameter.semMB_FRET = PIEdat.MB_FRET_sem{file};
    M.parameter.measTime = PIEdat.measTime(file)/1E6;
    
    % coincidence results
    if isfield(PIEdat, 'tccd')
        M.tccd.numMoleculesPIEall = PIEdat.tccd.NAall{file};
        M.tccd.numMoleculesFRETall = PIEdat.tccd.NDall{file};
        if PIEdat.l_fn>1 
            Nbursts(file,1)=M.tccd.numMoleculesPIEall;
            Nbursts(file,2)=M.tccd.numMoleculesFRETall;
            Nbursts(file,3)=Nbursts(file,2)/Nbursts(file,1);
        end    
        
        % global coincidence parameter (same number coincident bursts for
        % both channels)
        M.tccd.numMoleculesPIEsel_glob = PIEdat.tccd.NAsel{file};
        M.tccd.numMoleculesPIEsel_opt = PIEdat.tccd.NPIEsel_opt(file);
        M.tccd.numMoleculesPIEcoinc_glob = PIEdat.tccd.NAcoinc{file};
        M.tccd.numMoleculesPIEcoinc_opt = PIEdat.tccd.NPIEcoinc_opt(file);
        
        M.tccd.numMoleculesFRETsel_glob = PIEdat.tccd.NDsel{file};
        M.tccd.numMoleculesFRETsel_opt = PIEdat.tccd.NFRETsel_opt(file);
        M.tccd.numMoleculesFRETcoinc_glob = PIEdat.tccd.NDcoinc{file};
        M.tccd.numMoleculesFRETcoinc_opt = PIEdat.tccd.NFRETcoinc_opt(file);
        
        M.tccd.numMoleculesAcceptorOnly_glob = PIEdat.tccd.NA0{file};
        M.tccd.numMoleculesDonorOnly_glob = PIEdat.tccd.ND0{file};
        M.tccd.numMoleculesDonorAcceptorCoincidence_glob = PIEdat.tccd.NDA{file};
        M.tccd.numMoleculesTotal_glob = PIEdat.tccd.Ntot{file};
        M.tccd.FractionAcceptorOnly_glob = PIEdat.tccd.xA0{file};
        M.tccd.FractionDonorOnly_glob = PIEdat.tccd.xD0{file};
        M.tccd.FractionDonorAcceptorCoincidence_glob = PIEdat.tccd.xDA{file};
        M.tccd.FractionAcceptorOnly_err_glob = PIEdat.tccd.xA0_err{file};
        M.tccd.FractionDonorOnly_err_glob = PIEdat.tccd.xD0_err{file};
        M.tccd.FractionDonorAcceptorCoincidence_err_glob = PIEdat.tccd.xDA_err{file};
        
        % coincidence for individual channels
        M.tccd.FractionCoincPIE_glob = PIEdat.tccd.NAcoinc{file}/PIEdat.tccd.NAsel{file};
        M.tccd.FractionCoincPIE_optthres = 1 - PIEdat.tccd.noPIEcoinc_opt(file);
        M.tccd.precFractionCoincPIE_optthres = PIEdat.tccd.precPIEcoinc_opt(file);
        M.tccd.FractionNoCoincPIE_glob = 1 - M.tccd.FractionCoincPIE_glob;
        M.tccd.FractionNoCoincPIE_optthres = PIEdat.tccd.noPIEcoinc_opt(file);
        M.tccd.FractionCoincFRET_glob = PIEdat.tccd.NDcoinc{file}/PIEdat.tccd.NDsel{file};
        M.tccd.FractionCoincFRET_optthres = 1 - PIEdat.tccd.noFRETcoinc_opt(file);
        M.tccd.precFractionCoincFRET_optthres = PIEdat.tccd.precFRETcoinc_opt(file);
        M.tccd.FractionNoCoincFRET_glob = 1 - M.tccd.FractionCoincFRET_glob;
        M.tccd.FractionNoCoincFRET_optthres = PIEdat.tccd.noFRETcoinc_opt(file);
        M.tccd.FractionSelectBurstPIE_opt = PIEdat.tccd.frac_PIEsel_opt(file);
        M.tccd.FractionSelectBurstFRET_opt = PIEdat.tccd.frac_FRETsel_opt(file);
        M.tccd.FractionCoincPIE_fit = PIEdat.tccd.PIEcoinc_fit(file);
        M.tccd.errFractionCoincPIE_fit = PIEdat.tccd.errPIEcoinc_fit(file);
        M.tccd.FractionCoincFRET_fit = PIEdat.tccd.FRETcoinc_fit(file);
        M.tccd.errFractionCoincFRET_fit = PIEdat.tccd.errFRETcoinc_fit(file);
        
        % thresholds
        M.tccd.thrphotPIE = PIEdat.thrphotPIE(file);
        M.tccd.thrphotFRET = PIEdat.thrphotFRET(file);
        M.tccd.optthrPIE = PIEdat.optthrPIE(file);
        M.tccd.optthrFRET = PIEdat.optthrFRET(file);
        M.tccd.meanIPIE = PIEdat.mean_I_PIE(file);
        M.tccd.meanIFRET = PIEdat.mean_I_FRET(file);
        M.tccd.optthrPIErel = PIEdat.optthrPIErel(file);
        M.tccd.optthrFRETrel = PIEdat.optthrFRETrel(file);
    end
    % proximity ratio histogram results
    if isfield(PIEdat, 'proximity')
        M.ProximityRatio.numMoleculesAcceptorOnly = PIEdat.proximity.NA0_PIE{file};
        M.ProximityRatio.numMoleculesDonorAcceptorPIE = PIEdat.proximity.NDA_PIE{file};
        M.ProximityRatio.numMoleculesDonorOnly = PIEdat.proximity.ND0_FRET{file};
        M.ProximityRatio.numMoleculesDonorAcceptorFRET = PIEdat.proximity.NDA_FRET{file};
        M.ProximityRatio.numMoleculesDonorAcceptor = PIEdat.proximity.NDA{file};
        M.ProximityRatio.numMoleculesTotal = PIEdat.proximity.Nges{file};
        M.ProximityRatio.FractionDonorOnly = PIEdat.proximity.xD0{file};
        M.ProximityRatio.FractionAcceptorOnly = PIEdat.proximity.xA0{file};
        M.ProximityRatio.FractionDonorAcceptor = PIEdat.proximity.xDA{file};
        
        name_proximity = [PIEdat.defaultdirectory 'stoichiometry results\' PIEdat.filenameShort{file} '_proximity_results.mat'];
        if ~exist([PIEdat.defaultdirectory 'stoichiometry results\'],'dir')
            mkdir([PIEdat.defaultdirectory 'stoichiometry results\']);
        end
        save(name_proximity, '-struct', 'M', 'ProximityRatio');
    end
          
    % generate filenames for saving
    name_param = [PIEdat.defaultdirectory PIEdat.filenameShort{file} '_parameter.mat'];
    name_coinc = [PIEdat.defaultdirectory 'stoichiometry results\' PIEdat.filenameShort{file} '_coincidence_results.mat'];
        
    save(name_param, '-struct', 'M', 'parameter');
    if isfield(M, 'tccd')
        save(name_coinc, '-struct', 'M', 'tccd');
    end
    % save plots but just for 1st file
    if file==1      
        Fig1 = figure;
        set(gcf,'Visible','on','PaperPositionMode','auto');
        copyobj(handles.AX_IPDtrace, Fig1);

        Fig2 = figure;
        set(gcf,'Visible','on','PaperPositionMode','auto')
        copyobj(handles.AX_PIEhist, Fig2);

        Fig3 = figure;
        set(gcf,'Visible','on','PaperPositionMode','auto')
        copyobj(handles.AX_DAhist, Fig3);

        Fig4 = figure;
        set(gcf,'Visible','on','PaperPositionMode','auto')
        copyobj(handles.AX_BurstWidthPIE, Fig4);

        Fig5 = figure;
        set(gcf,'Visible','on','PaperPositionMode','auto')
        copyobj(handles.AX_BurstWidthDA, Fig5);

        if ~exist([PIEdat.defaultdirectory 'figures\'],'dir')
            mkdir([PIEdat.defaultdirectory 'figures\']);
        end
        
        hgsave(Fig1, [PIEdat.defaultdirectory 'figures\' PIEdat.filenameShort{file} '_PIEtraces.fig']);
        hgsave(Fig2, [PIEdat.defaultdirectory 'figures\' PIEdat.filenameShort{file} '_IPDhistPIE.fig']);
        hgsave(Fig3, [PIEdat.defaultdirectory 'figures\' PIEdat.filenameShort{file} '_IPDhistDA.fig']);
        hgsave(Fig4, [PIEdat.defaultdirectory 'figures\' PIEdat.filenameShort{file} '_BurstWidthPIE.fig']);
        hgsave(Fig5, [PIEdat.defaultdirectory 'figures\' PIEdat.filenameShort{file} '_BurstWidthDA.fig']);

        close(Fig1);
        close(Fig2);
        close(Fig3);
        close(Fig4);
        close(Fig5);
    end
    
    % update progress visualization
    disp(['... ' num2str(file) '/' num2str(PIEdat.l_fn) ' done.']);
    waitbar(file/PIEdat.l_fn, wbarh);                                     % update waitbar
    
end

if PIEdat.l_fn>1 
    name_Nbursts = [PIEdat.defaultdirectory 'stoichiometry results\' PIEdat.filenameShort{1} '_Nbursts.dat'];
    save(name_Nbursts, 'Nbursts', '-ascii', '-tabs');
end

close(wbarh); 
disp('-------------------------------------------------')

