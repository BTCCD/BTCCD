function CalculateIPD_MoleculeSorting(hObject, ~, handles)
% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (BTCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%CALCULATEIPD_MOLECULESORTING   Calculates and displays the Inter-Photon-
%                               Distance traces for various channels and
%                               time windows.

% hObject       handle to PB_SaveApproximationXPLOR (see GCBO)
% eventdata     reserved - to be defined in a future version of MATLAB
% handles       structure with handles and user data (see GUIDATA)

% INPUTS        All input are taken from global cell variable 'PIEdat'
% OUTPUT        All outputs are written to global cell variable 'PIEdat'

% Inputs are:   t_*timewindow*_*channel* =  macro time vector where
%                                           *timewindow* = FRET,PIE
%                                           *channel* = D,A,DA
%               m*window* = the half-width of the smoothing filter for the
%                           time window *window* (FRET=D+A,PIE=A)
%                           (Seidel et al.,J.Phys.Chem.,102,pp.6601,1998)
% Outputs are:  l_smooth_IPD_*timewindow*_*channel* = vector of smoothed
%                                                     and logarithm of IPD
%                                                     *timewindow* = FRET,PIE
%                                                     *channel* = D,A,DA
%               bg_*timewindow*_*channel* = bg countrate for
%                                           *timewindow* = FRET,PIE
%                                           *channel* = D,A,DA
%               l_IPDburstThreshold_*timewindow*_*channel* = logarithm of 
%                                                            IPD threshold 
%                                                            for burst
%                                                            identification

global PIEdat                                                              % global variable

% delete variables that are no longer needed
if isfield(PIEdat,'INPUT')
    PIEdat=rmfield(PIEdat,'INPUT');
end    
   
% preallocate variables
PIEdat.hist_IPD_PIE = cell(1,PIEdat.l_fn);
PIEdat.hist_IPD_D = cell(1,PIEdat.l_fn);
PIEdat.hist_IPD_A = cell(1,PIEdat.l_fn);
PIEdat.hist_IPD_DA = cell(1,PIEdat.l_fn);
bg_IPD_D = zeros(1,PIEdat.l_fn);
bg_IPD_A = zeros(1,PIEdat.l_fn);

wbarh = waitbar(0,'IPD is calculated...');

for n = 1:PIEdat.l_fn
    % Calculation of the interphoton distance vector for accepor in PIE window
    t_UB_PIE = cat(1,PIEdat.t_PIE_A{n},PIEdat.T_end(n)+1000000);                     % add additional time at end of t_PIE_A{n}        
    t_LB_PIE = cat(1,0,PIEdat.t_PIE_A{n});                                           % add 0 to beginning of t_PIE_A{n}
    IPD_PIE = t_UB_PIE-t_LB_PIE;                                                       % calculate IPD vector
    IPD_PIE = double(IPD_PIE);                                                 % convert to double
    IPD_PIE = (IPD_PIE(1:(length(IPD_PIE)-1))).* 10^-3;                        % convert from ns to �s time scale; delete last point
    if n==1
        l_IPD_PIE = log10(IPD_PIE);                                        % build logarithm to plot IPD just for 1st measurement
    end
    smooth_IPD_PIE = moving_average(IPD_PIE,PIEdat.mPIE,1);                    % smooth IPD time trace with the moving average filter (function moving_average.m needed!)
    PIEdat.l_smooth_IPD_PIE_A{n} = log10(smooth_IPD_PIE);                        % build logarithm of smoothed IPD trace
    
    clear t_UB_PIE t_LB_PIE IPD_PIE smooth_IPD_PIE
    
    % Calculation of the interphoton distance vector for the donor in the FRET window
    t_UB_FRET_D = cat(1,PIEdat.t_FRET_D{n},PIEdat.T_end(n)+1000000);       
    t_LB_FRET_D = cat(1,0,PIEdat.t_FRET_D{n});
    IPD_D = t_UB_FRET_D-t_LB_FRET_D;
    IPD_D = double(IPD_D);
    IPD_D = (IPD_D(1:(length(IPD_D)-1))).*10^-3;
    smooth_IPD_D = moving_average(IPD_D,PIEdat.mDA,1);
    PIEdat.l_smooth_IPD_FRET_D{n} = log10(smooth_IPD_D);
       
    clear t_UB_FRET_D t_LB_FRET_D IPD_D smooth_IPD_D
    
    % Calculation of the interphoton distance vector for the acceptor in the FRET window
    t_UB_FRET_A = cat(1,PIEdat.t_FRET_A{n},PIEdat.T_end(n)+1000000);       
    t_LB_FRET_A = cat(1,0,PIEdat.t_FRET_A{n});
    IPD_A = t_UB_FRET_A-t_LB_FRET_A;
    IPD_A = double(IPD_A);
    IPD_A = (IPD_A(1:(length(IPD_A)-1))).*10^-3;
    smooth_IPD_A = moving_average(IPD_A,PIEdat.mDA,1);
    PIEdat.l_smooth_IPD_FRET_A{n} = log10(smooth_IPD_A); 
    
    clear t_UB_FRET_A t_LB_FRET_A IPD_A smooth_IPD_A

    % Calculation of the interphotons vector for both channels in the FRET
    % window (added by Henning on 2014/12/01)
    t_UB_FRET_DA = cat(1,PIEdat.t_FRET_DA{n},PIEdat.T_end(n)+1000000);          % add donor and acceptor macrotimes
    t_LB_FRET_DA = cat(1,0,PIEdat.t_FRET_DA{n});
    IPD_DA = t_UB_FRET_DA-t_LB_FRET_DA;
    IPD_DA = double(IPD_DA);
    IPD_DA = (IPD_DA(1:(length(IPD_DA)-1))).*10^-3;
    if n==1
        l_IPD_DA = log10(IPD_DA);
    end
    smooth_IPD_DA = moving_average(IPD_DA, PIEdat.mDA, 1);
    PIEdat.l_smooth_IPD_FRET_DA{n} = log10(smooth_IPD_DA);
    
    clear t_UB_FRET_DA t_LB_FRET_DA IPD_DA smooth_IPD_DA
    
    % Calculation of the interphotons vector for both channels in both time
    % windows (added by Henning on 2017/05/30)
    t_UB_ALL_DA = cat(1,PIEdat.t_ALL_DA{n},PIEdat.T_end(n)+1000000);          % add donor and acceptor macrotimes
    t_LB_ALL_DA = cat(1,0,PIEdat.t_ALL_DA{n});
    IPD_ALL_DA = t_UB_ALL_DA - t_LB_ALL_DA;
    IPD_ALL_DA = double(IPD_ALL_DA);
    IPD_ALL_DA = (IPD_ALL_DA(1:(length(IPD_ALL_DA)-1))).*10^-3;
    if n==1
        l_IPD_ALL_DA = log10(IPD_ALL_DA);
    end
    smooth_IPD_ALL_DA = moving_average(IPD_ALL_DA, PIEdat.mDA, 1);
    PIEdat.l_smooth_IPD_ALL_DA{n} = log10(smooth_IPD_ALL_DA);
    
    clear t_UB_ALL_DA t_LB_ALL_DA IPD_ALL_DA smooth_IPD_ALL_DA
    
    % Build IPD histograms of smoothed IPD traces
    step_IPD = 0.05;                                                           % step_IPD size for histogram bins 
    x_IPD_distr = -1:step_IPD:6;                                                   

    PIEdat.hist_IPD_PIE{n} = hist(PIEdat.l_smooth_IPD_PIE_A{n}, x_IPD_distr);
    PIEdat.hist_IPD_D{n} = hist(PIEdat.l_smooth_IPD_FRET_D{n},x_IPD_distr);
    PIEdat.hist_IPD_A{n} = hist(PIEdat.l_smooth_IPD_FRET_A{n},x_IPD_distr);
    PIEdat.hist_IPD_DA{n} = hist(PIEdat.l_smooth_IPD_FRET_DA{n},x_IPD_distr);
    PIEdat.x_IPD_distr = x_IPD_distr;

    % Calculate background count rates for all channels + time windows as maximum of the corresponding IPD histograms
    start_bg = 3/step_IPD;
    offset_bg = 3 - step_IPD;
    max_IPDhist_PIE = 10.^(x_IPD_distr(PIEdat.hist_IPD_PIE{n}(start_bg:end) == max(PIEdat.hist_IPD_PIE{n}(start_bg:end))) + offset_bg);
    PIEdat.bg_IPD_PIE(n) = max_IPDhist_PIE(1);                                                  % in case of 2 bins select lower background IPD
    PIEdat.bg_PIE_A(n) = (1/PIEdat.bg_IPD_PIE(n))*1E6;                                              % count rates (1/IPD) [s]
    max_IPDhist_D = 10.^(x_IPD_distr(PIEdat.hist_IPD_D{n}(start_bg:end) == max(PIEdat.hist_IPD_D{n}(start_bg:end))) + offset_bg);
    bg_IPD_D(n) = max_IPDhist_D(1);
    PIEdat.bg_FRET_D(n) = (1/bg_IPD_D(n))*1E6;                                              
    max_IPDhist_A = 10.^(x_IPD_distr(PIEdat.hist_IPD_A{n}(start_bg:end) == max(PIEdat.hist_IPD_A{n}(start_bg:end))) + offset_bg);
    bg_IPD_A(n) = max_IPDhist_A(1);
    PIEdat.bg_FRET_A(n) = (1/bg_IPD_A(n))*1E6;
    max_IPDhist_DA = 10.^(x_IPD_distr(PIEdat.hist_IPD_DA{n}(start_bg:end) == max(PIEdat.hist_IPD_DA{n}(start_bg:end))) + offset_bg);
    PIEdat.bg_IPD_DA(n) = max_IPDhist_DA(1);
    PIEdat.bg_FRET_DA(n) = (1/PIEdat.bg_IPD_DA(n))*1E6;

    if get(handles.CB_AutomatedThreshold, 'Value')==1
        PIEdat.IPDburstThreshold_PIE_A(n) = PIEdat.IPDthres_bg_fraction_PIE*PIEdat.bg_IPD_PIE(n);                                        
        PIEdat.IPDburstThreshold_FRET_DA(n) = PIEdat.IPDthres_bg_fraction_FRET*PIEdat.bg_IPD_DA(n);
        PIEdat.l_IPDburstThreshold_PIE_A(n) = log10(PIEdat.IPDburstThreshold_PIE_A(n));        
        PIEdat.l_IPDburstThreshold_FRET_DA(n) = log10(PIEdat.IPDburstThreshold_FRET_DA(n));
        set(handles.ET_IPDburstThreshold_PIE, 'String', num2str(PIEdat.IPDburstThreshold_PIE_A(1),3));
        set(handles.ET_IPDburstThreshold_DA, 'String', num2str(PIEdat.IPDburstThreshold_FRET_DA(1),3));
    end    

     waitbar(n/PIEdat.l_fn, wbarh);  
end

% % Temporaray
% IPL_PIE(:,1) = PIEdat.t_PIE_A{1}.*10^-9;
% IPL_PIE(:,2) = l_IPD_PIE;
% IPL_PIE(:,3) = PIEdat.l_smooth_IPD_PIE_A{1};
% IPL_FRET(:,1) = PIEdat.t_FRET_DA{1}.*10^-9;
% IPL_FRET(:,2) = l_IPD_DA;
% IPL_FRET(:,3) = PIEdat.l_smooth_IPD_FRET_DA{1};
% save('IPL_trace_PIE.dat','IPL_PIE','-ascii');
% save('IPL_trace_FRET.dat','IPL_FRET','-ascii');
% % Temporary end

% Plot IPD histograms 
axes(handles.AX_PIEhist);                                                  % set current axes for histogram
cla                                                                 % clear current axes
hist(PIEdat.l_smooth_IPD_PIE_A{1},x_IPD_distr);
xlabel('log_1_0IPD / \mus')
ylabel('# of photons')
xlim([-1 6]);
text(0,0.9*max(PIEdat.hist_IPD_PIE{1}),['<IDP>_{BG} = ', num2str(PIEdat.bg_IPD_PIE(1)/1000,3) ' ms'],'FontSize',10,'EdgeColor','black');

axes(handles.AX_Dhist);                                                  % set current axes for histogram
cla;   
hist(PIEdat.l_smooth_IPD_FRET_D{1},x_IPD_distr);
xlabel('log_1_0IPD / \mus')
xlim([-1 6]);
ylabel('# of photons')
text(0,0.9*max(PIEdat.hist_IPD_D{1}),['<IDP>_{BG} = ', num2str(bg_IPD_D(1)/1000,3) ' ms'],'FontSize',10,'EdgeColor','black');

axes(handles.AX_Ahist);                                                  % set current axes for histogram
cla;   
hist(PIEdat.l_smooth_IPD_FRET_A{1},x_IPD_distr);
xlabel('log_1_0IPD / \mus')
xlim([-1 6]);
ylabel('# of photons')
text(0,0.9*max(PIEdat.hist_IPD_A{1}),['<IDP>_{BG} = ', num2str(bg_IPD_A(1)/1000,3) ' ms'],'FontSize',10,'EdgeColor','black');

axes(handles.AX_DAhist);                                                  % set current axes for histogram
cla;   
hist(PIEdat.l_smooth_IPD_FRET_DA{1},x_IPD_distr);
xlabel('log_1_0IPD / \mus')
xlim([-1 6]);
ylabel('# of events')
text(0,0.9*max(PIEdat.hist_IPD_DA{1}),['<IDP>_{BG} = ', num2str(PIEdat.bg_IPD_DA(1)/1000,3) ' ms'],'FontSize',10,'EdgeColor','black');

disp = 1E5;
if length(PIEdat.t_PIE_A{1})<disp || length(PIEdat.t_FRET_DA{1})<disp
    disp = min(length(PIEdat.t_PIE_A{1}),length(PIEdat.t_FRET_DA{1}));
end    
dispPIE = PIEdat.t_PIE_A{1}(disp);
dispDA = PIEdat.t_FRET_DA{1}(disp);
t_disp = min(dispPIE,dispDA);
dispPIE = find(PIEdat.t_PIE_A{1}>t_disp,1);
dispDA = find(PIEdat.t_FRET_DA{1}>t_disp,1);
dispALL = find(PIEdat.t_ALL_DA{1}>t_disp,1);

t_PIE_IPD_trace = PIEdat.t_PIE_A{1}(1:dispPIE).*10^-9;
PIEdat.t_PIE_IPD_trace = t_PIE_IPD_trace;
%t_FRET_D_IPD_trace = PIEdat.t_FRET_D{1}.*10^-9;                             % set value of time axis to seconds
%t_FRET_A_IPD_trace = PIEdat.t_FRET_A{1}.*10^-9;                          % set value of time axis to seconds
t_FRET_DA_IPD_trace = PIEdat.t_FRET_DA{1}(1:dispDA).*10^-9;                    % set value of time axis to seconds
PIEdat.t_DA_IPD_trace = t_FRET_DA_IPD_trace;
t_ALL_IPD_trace = PIEdat.t_ALL_DA{1}(1:dispALL).*10^-9;


% Additionally plot the IPD traces itself
axes(handles.AX_IPDtrace);                                                  % set current axes for histogram
cla;   % get current axes

plot(t_PIE_IPD_trace(1:dispPIE), l_IPD_PIE(1:dispPIE),'Marker', '+', 'MarkerSize', 2, 'LineStyle', 'none')
hold on;
plot(t_FRET_DA_IPD_trace(1:dispDA), l_IPD_DA(1:dispDA),'Marker', '+', 'MarkerSize', 2, 'LineStyle', 'none', 'Color',[1 0 1])
plot(t_PIE_IPD_trace(1:dispPIE), PIEdat.l_smooth_IPD_PIE_A{1}(1:dispPIE), 'Marker', 'o', 'MarkerSize', 2,'LineWidth', 1)
plot(t_FRET_DA_IPD_trace(1:dispDA), PIEdat.l_smooth_IPD_FRET_DA{1}(1:dispDA),'Marker', 'o', 'MarkerSize', 2, 'LineWidth', 1, 'Color',[1 0 1])
plot(t_ALL_IPD_trace(1:dispALL), PIEdat.l_smooth_IPD_ALL_DA{1}(1:dispALL),'Marker', 'o', 'MarkerSize', 2, 'LineWidth', 1, 'Color',[0 0 0])

pl_l_PIE_burst_threshold = ones(1,dispPIE).*PIEdat.l_IPDburstThreshold_PIE_A(1);
pl_l_DA_burst_threshold = ones(1,dispDA).*PIEdat.l_IPDburstThreshold_FRET_DA(1);
pl_IPD_BG_PIE = log10(ones(1,dispPIE).*PIEdat.bg_IPD_PIE(1));
pl_IPD_BG_DA = log10(ones(1,dispDA).*PIEdat.bg_IPD_DA(1));

plot(t_PIE_IPD_trace(1:dispPIE), pl_l_PIE_burst_threshold,'k --','LineWidth',2);
plot(t_FRET_DA_IPD_trace(1:dispDA), pl_l_DA_burst_threshold,'c --','LineWidth',2);
plot(t_PIE_IPD_trace(1:dispPIE),pl_IPD_BG_PIE,'g --','LineWidth',2);
plot(t_FRET_DA_IPD_trace(1:dispDA),pl_IPD_BG_DA,'r --','LineWidth',2);
xlabel('Time / s')
ylabel('log_1_0IPD_P_I_E / \mus')
legend({'PIE', 'D+A FRET', 'PIE smoothed', 'FRET D+A smoothed', 'ALL smoothed', 'PIE Threshold', 'D+A FRET Threshold','Average Background PIE', 'Average Background D+A FRET'}, 'FontSize',8);
hold off;

clear l_IPD_PIE l_IPD_DA
clear pl_l_PIE_burst_threshold pl_l_DA_burst_threshold pl_IPD_BG_PIE pl_IPD_BG_DA
clear t_FRET_DA_IPD_trace t_PIE_IPD_trace

guidata(hObject, handles);                                                 % update handles structure
close(wbarh);

end

