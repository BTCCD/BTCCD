function LoadInput(hObject, eventdata, handles)

% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (BTCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

%LOADINPUT  Loads user specified input file(s).

% hObject       handle to PB_SaveApproximationXPLOR (see GCBO)
% eventdata     reserved - to be defined in a future version of MATLAB
% handles       structure with handles and user data (see GUIDATA)

%   OUTPUT      All outputs are written to global cell variable 'PIEdat'

% Outputs are:  l_fn = number of input files
%               filenameShort{i} = filename(s) of input file(s) i without ending
%               INPUT{i} = input data i where each line represents a photon,
%                          columns are:
%                          1st column: Channel number
%                          2nd column: Macro time (in ns)
%                          3rd column: Micro time (in number of time bins 
%                                      since last laser excitation)
%               defaultdirectory = directory where input files are located
%               T_start(i) = macro starting time of measurement i
%               T_end(i) = macro ending time of measurement i
%               T_measTime(i) = duration of measurement i
%               numberMicroChannels = maximum number of micro time channels

global PIEdat                                                              % global variable

% Load the INPUT file (.dat)
[filename, pathname] = uigetfile('*.dat', 'Load .dat file','MultiSelect','on');

set(handles.ST_datPath, 'String', 'loading...');
guidata(hObject, handles);                                                 % update handles structure

if isequal(filename,0) || isequal(pathname,0)                              % User selected "Cancel"
    set(handles.ST_datPath, 'String', '');
    return
else
    % Reset all variables
    InitializeUserVariables(hObject, eventdata, handles);
    
    % Set the number of selected .dat files
    if ~iscell(filename)
        filename_tmp = filename;
        filename = cell(1);
        filename{1} = filename_tmp;
    end    
    PIEdat.l_fn = length(filename);
    
    % Load .dat file
    disp('-------------------------------------------------');
    disp(['loading ' num2str(PIEdat.l_fn) ' .dat file(s) ...']);
    wbarh = waitbar(0,'Data is loaded. Please wait...');                                % create waitbar
    for i=1:PIEdat.l_fn
        path = [pathname, filename{1,i}];
        PIEdat.filenameShort{i} = filename{1,i}(1:end-4);
        %numlines=str2num(perl('countlines.pl', filename{1,i}))-2;
        %PIEdat.INPUT{i} = zeros(numlines,3);
%         PIEdat.INPUT{i} = importdata(path, ' ', 2)
%         [PIEdat.INPUT{i} , ~, nheadliners] = importdata(path);
%         if nheadliners > 0
%            PIEdat.INPUT{i} = PIEdat.INPUT{i}.data;                       % files generated in J�lich have 2 header lines
%         end

        fid = fopen(path);
        
        % check if header lines exist(J�lich) or not (Aachen)
        firstline = fgetl(fid);
        if isempty(firstline)
            numHeaders = 2;                                                % J�lich files begin with empty line followed by one header line
        else
            numHeaders = 0;                                                % Aachen files have no header lines
        end
        
        % read the data
        tmp = textscan(fid,'%u8 %u64 %u16','HeaderLines',numHeaders);
        PIEdat.INPUT{i} = zeros(size(tmp{1,1},1),3);                       % create matrix with zeros
        PIEdat.INPUT{i}(:,1) = tmp{1,1};
        PIEdat.INPUT{i}(:,2) = tmp{1,2};
        PIEdat.INPUT{i}(:,3) = tmp{1,3};
        clear tmp numHeaders
        fclose(fid);

        % update progress visualization
        disp(['... ' num2str(i) '/' num2str(PIEdat.l_fn) ' done.']);
        waitbar(i/PIEdat.l_fn, wbarh);                                     % update waitbar
    end
        
    disp('-------------------------------------------------')
    PIEdat.defaultdirectory = pathname;
        
    % Calculation of the total measurament time
    for i=1:PIEdat.l_fn
        PIEdat.T_start(i) = PIEdat.INPUT{i}(1,2);                          % starting time of the measurament
        PIEdat.T_end(i) = PIEdat.INPUT{i}(length(PIEdat.INPUT{i}),2);      % ending time of the measurement
        PIEdat.measTime(i) = PIEdat.T_end(i) - PIEdat.T_start(i);          % total measurement time
    end
        
    % Calculation of the number of microchannels and time resolution
    PIEdat.numberMicroChannels = max(PIEdat.INPUT{1}(:,3));
    if PIEdat.numberMicroChannels < 6252
        PIEdat.time_resolution = 0.016;
        set(handles.ST_TimeResolution, 'String', 'time res. = 16ps');
    else
        PIEdat.time_resolution = 0.032;
        set(handles.ST_TimeResolution, 'String', 'time res. = 32ps');
    end    
    
    % Display selected path in text field  
    if length(path) > 28                                                   % if the path name is too long ...
        dispstring = ['...' path(end-28:end)];                             % ... shorten it
    else
        dispstring = path;                                                 % ... otherwise
    end
    set(handles.ST_datPath, 'String', dispstring);
end

%% Temporary to generate files that contain onl 1st, only 1st+2nd, only 1st+2nd+3rd , ......
%     tmp = PIEdat.INPUT{1};
%         for ii = 2:1:PIEdat.l_fn       
%             tmp_add = zeros(length(PIEdat.INPUT{ii}(:,1)),3);
%             tmp_add(:,1) =  PIEdat.INPUT{ii}(:,1);
%             tmp_add(:,2) =  PIEdat.INPUT{ii}(:,2) + tmp(end,2);
%             tmp_add(:,3) =  PIEdat.INPUT{ii}(:,3);
%             tmp = vertcat(tmp, tmp_add);
%             PIEdat.INPUT{ii}=tmp;
%             
%             PIEdat.T_start(ii) = PIEdat.INPUT{1}(1,2);                          % starting time of the measurament
%             PIEdat.T_end(ii) = PIEdat.INPUT{ii}(length(PIEdat.INPUT{ii}),2);      % ending time of the measurement
%             PIEdat.measTime(ii) = PIEdat.T_end(ii) - PIEdat.T_start(ii);  
%         end
% Temporary End

% %% Temporary to generate subfiles out of 1 file
%     tmp = PIEdat.INPUT{1};
%     PIEdat.INPUT{1}= zeros(1,3);
%     measTime = PIEdat.measTime(1);
%     numchunks = 2;
%     PIEdat.l_fn=numchunks;
%     chunktime = measTime/numchunks;
%         for ii = 1:1:numchunks       
%             ind = tmp(:,2)<ii*chunktime;
%             PIEdat.INPUT{ii}= zeros(sum(ind),3);
%             PIEdat.INPUT{ii}(:,1) = tmp(ind,1);
%             PIEdat.INPUT{ii}(:,2) = tmp(ind,2);
%             PIEdat.INPUT{ii}(:,3) = tmp(ind,3);            
%             PIEdat.T_start(ii) = PIEdat.INPUT{ii}(1,2);                          % starting time of the measurament
%             PIEdat.T_end(ii) = PIEdat.INPUT{ii}(length(PIEdat.INPUT{ii}),2);      % ending time of the measurement
%             PIEdat.measTime(ii) = PIEdat.T_end(ii) - PIEdat.T_start(ii);
%             PIEdat.filenameShort{ii} = ['file' num2str(ii)];
%         end
%%Temporary End

   %% Temporaray to add all files
    tmp = zeros(1,3);
    tmp = PIEdat.INPUT{1};
    for ii = 2:1:PIEdat.l_fn        
        tmp_add = zeros(length(PIEdat.INPUT{ii}(:,1)),3);
        tmp_add(:,1) =  PIEdat.INPUT{ii}(:,1);
        tmp_add(:,2) =  PIEdat.INPUT{ii}(:,2) + tmp(end,2);
        tmp_add(:,3) =  PIEdat.INPUT{ii}(:,3);
        tmp = vertcat(tmp, tmp_add);
        PIEdat.INPUT{ii} = [];
    end
    PIEdat.INPUT{1}=tmp;
    PIEdat.l_fn = 1;
    PIEdat.T_start(1) = PIEdat.INPUT{1}(1,2);                          % starting time of the measurament
    PIEdat.T_end(1) = PIEdat.INPUT{1}(length(PIEdat.INPUT{1}),2);      % ending time of the measurement
    PIEdat.measTime(1) = PIEdat.T_end(1) - PIEdat.T_start(1);
    %% Temporary end

close(wbarh);                                                              % close waitbar
guidata(hObject, handles);                                                 % update handles structure
end

