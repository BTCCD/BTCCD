function varargout = smFRET(varargin)
% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (TCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

% TCCD M-file for TCCD.fig
%      TCCD, by itself, creates a new TCCD or raises the existing
%      singleton*.
%
%      H = TCCD returns the handle to a new TCCD or the handle to
%      the existing singleton*.
%
%      TCCD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TCCD.M with the given input arguments.
%
%      TCCD('Property','Value',...) creates a new TCCD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TCCD_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TCCD_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help TCCD

% Last Modified by GUIDE v2.5 14-Jun-2017 14:36:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TCCD_OpeningFcn, ...
                   'gui_OutputFcn',  @TCCD_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TCCD is made visible.
function TCCD_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to TCCD (see VARARGIN)

set(handles.MolSort, 'units', 'normalized', 'position', [0.05 0.15 0.9 0.8])

% initialize user variables
InitializeUserVariables(hObject, eventdata, handles);

% Choose default command line output for TCCD
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes TCCD wait for user response (see UIRESUME)
% uiwait(handles.TCCD);


% --- Outputs from this function are returned to the command line.
function varargout = TCCD_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in PB_LoadFile.
% --- Loads the .dat input file.
function PB_LoadFile_Callback(hObject, eventdata, handles)
% hObject    handle to PB_LoadFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

LoadInput(hObject, eventdata, handles)


function ET_DonorChannel_Callback(hObject, eventdata, handles)
% hObject    handle to ET_DonorChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_DonorChannel as text
%        str2double(get(hObject,'String')) returns contents of ET_DonorChannel as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry < 0
    set(hObject, 'String', PIEdat.donor_chan);
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.donor_chan = user_entry;                                            % set donor channel to user's entry


% --- Executes during object creation, after setting all properties.
function ET_DonorChannel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_DonorChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function ET_AcceptorChannel_Callback(hObject, eventdata, handles)
% hObject    handle to ET_AcceptorChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_AcceptorChannel as text
%        str2double(get(hObject,'String')) returns contents of ET_AcceptorChannel as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry < 0
	set(hObject, 'String', PIEdat.acceptor_chan);
    errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.acceptor_chan = user_entry;                                         % set acceptor channel to user's entry



% --- Executes during object creation, after setting all properties.
function ET_AcceptorChannel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_AcceptorChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in PB_DisplayTCSPC.
function PB_DisplayTCSPC_Callback(hObject, eventdata, handles)
% hObject    handle to PB_DisplayTCSPC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PIEdat

if PIEdat.l_fn < 1
  	errordlg('Please specify an input file','Bad Input','modal')
	return
elseif ( isempty(PIEdat.donor_chan) || isempty(PIEdat.acceptor_chan) )
  	errordlg('Please specify donor and acceptor channels','Bad Input','modal')
	return
elseif ( isempty(PIEdat.dt_start_window_FRET) || isempty(PIEdat.dt_start_window_PIE) )
    errordlg('Please specify the starting time channels','Bad Input','modal')
	return
elseif ~isfield(PIEdat,'INPUT')
    errordlg('Input data is deleted when BURST_COORDINTES are calculated due to memory reasons. Please load the file(s) again!','Bad Input','modal')
    return 
end

DisplayTCSPC(hObject, eventdata, handles)



function ET_StartPIEChannel_Callback(hObject, eventdata, handles)
% hObject    handle to ET_StartPIEChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_StartPIEChannel as text
%        str2double(get(hObject,'String')) returns contents of ET_StartPIEChannel as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.dt_start_window_PIE = user_entry;                                   % set starting time channel of PIE window to user's entry
PIEdat.dt_end_window_PIE = PIEdat.dt_start_window_PIE + 1500;              % set ending time channel of PIE window 
set(handles.ET_StartPIEChannel, 'String', PIEdat.dt_start_window_PIE);     % update displayed values
set(handles.ET_EndPIEChannel, 'String', PIEdat.dt_end_window_PIE);         % update displayed values


% --- Executes during object creation, after setting all properties.
function ET_StartPIEChannel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_StartPIEChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_StartFRETChannel_Callback(hObject, eventdata, handles)
% hObject    handle to ET_StartFRETChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_StartFRETChannel as text
%        str2double(get(hObject,'String')) returns contents of ET_StartFRETChannel as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.dt_start_window_FRET = user_entry;                                  % set starting time channel of FRET window to user's entry
PIEdat.dt_end_window_FRET = PIEdat.dt_start_window_FRET + 1500;            % set ending time channel of FRET window 
set(handles.ET_StartFRETChannel, 'String', PIEdat.dt_start_window_FRET);   % update displayed values
set(handles.ET_EndFRETChannel, 'String', PIEdat.dt_end_window_FRET);       % update displayed values


% --- Executes during object creation, after setting all properties.
function ET_StartFRETChannel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_StartFRETChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in PB_ClaculateIPD.
function PB_ClaculateIPD_Callback(hObject, eventdata, handles)
% hObject    handle to PB_ClaculateIPD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PIEdat

if isempty(PIEdat.t_PIE_A)
    errordlg('Please display the raw data first','Bad Input','modal')
    return
end

CalculateIPD_MoleculeSorting(hObject, eventdata, handles);




function ET_MovingAverageWidth_PIE_Callback(hObject, eventdata, handles)
% hObject    handle to text_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of text_m as text
%        str2double(get(hObject,'String')) returns contents of text_m as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry < 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.mPIE = user_entry;                                                  % set width of moving average filter to user's entry



% --- Executes during object creation, after setting all properties.
function ET_MovingAverageWidth_PIE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_IPDburstThreshold_PIE_Callback(hObject, eventdata, handles)
% hObject    handle to ET_IPDburstThreshold_PIE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_IPDburstThreshold_PIE as text
%        str2double(get(hObject,'String')) returns contents of ET_IPDburstThreshold_PIE as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
elseif ~isempty(PIEdat.bg_IPD_PIE)
    if PIEdat.bg_IPD_PIE/3 <= user_entry                                      % user entered too high IPD burst threshold
        %PIEdat.IPDburstThreshold_PIE_A = user_entry/3;
        %set(hObject, 'String', PIEdat.IPDburstThreshold_PIE_A);
        errordlg('IPD threshold too high!', 'Bad Input', 'modal');
        %return
    end   
end
                                 
for file = 1:PIEdat.l_fn
    PIEdat.IPDburstThreshold_PIE_A(file) = user_entry;                        % set IPD burst theshold to user's entry
    PIEdat.l_IPDburstThreshold_PIE_A(file) = log10(user_entry);
end    


% --- Executes during object creation, after setting all properties.
function ET_IPDburstThreshold_PIE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_IPDburstThreshold_PIE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function ST_meanIPD_PIE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ST_meanIPD_PIE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in PB_CalculateBurst.
function PB_CalculateBurst_Callback(hObject, eventdata, handles)
% hObject    handle to PB_CalculateBurst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PIEdat

%CalculateBursts_Klenermann_optThresh(hObject, eventdata, handles);
CalculateBursts(hObject, eventdata, handles);


function ET_EndFRETChannel_Callback(hObject, eventdata, handles)
% hObject    handle to ET_EndFRETChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_EndFRETChannel as text
%        str2double(get(hObject,'String')) returns contents of ET_EndFRETChannel as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.dt_end_window_FRET = user_entry;                                   % set ending time channel of FRET window 
set(handles.ET_EndFRETChannel, 'String', PIEdat.dt_end_window_FRET);         % update displayed values


% --- Executes during object creation, after setting all properties.
function ET_EndFRETChannel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_EndFRETChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function ET_EndPIEChannel_Callback(hObject, eventdata, handles)
% hObject    handle to ET_EndPIEChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_EndPIEChannel as text
%        str2double(get(hObject,'String')) returns contents of ET_EndPIEChannel as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.dt_end_window_PIE = user_entry;
set(handles.ET_EndPIEChannel, 'String', PIEdat.dt_end_window_PIE);         % update displayed values


% --- Executes during object creation, after setting all properties.
function ET_EndPIEChannel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_EndPIEChannel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_IPDburstThreshold_DA_Callback(hObject, eventdata, handles)
% hObject    handle to ET_IPDburstThreshold_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_IPDburstThreshold_DA as text
%        str2double(get(hObject,'String')) returns contents of ET_IPDburstThreshold_DA as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
elseif ~isempty(PIEdat.bg_IPD_DA)
    if PIEdat.bg_IPD_DA/3 <= user_entry                                    % user entered too high IPD burst threshold
        %PIEdat.IPDburstThreshold_FRET_DA = user_entry/3;
        %set(hObject, 'String', PIEdat.IPDburstThreshold_FRET_DA);
        errordlg('IPD threshold is too high!', 'Bad Input', 'modal');
        %return
    end   
end

for file = 1:PIEdat.l_fn
    PIEdat.IPDburstThreshold_FRET_DA(file) = user_entry;                                 % set IPD burst theshold to user's entry
    PIEdat.l_IPDburstThreshold_FRET_DA(file) = log10(user_entry);
end    



% --- Executes during object creation, after setting all properties.
function ET_IPDburstThreshold_DA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_IPDburstThreshold_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_MovingAverageWidth_DA_Callback(hObject, eventdata, handles)
% hObject    handle to ET_MovingAverageWidth_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_MovingAverageWidth_DA as text
%        str2double(get(hObject,'String')) returns contents of ET_MovingAverageWidth_DA as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry < 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.mDA = user_entry;     


% --- Executes during object creation, after setting all properties.
function ET_MovingAverageWidth_DA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_MovingAverageWidth_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_PIEBurstThresh_Callback(hObject, eventdata, handles)
% hObject    handle to ET_PIEBurstThresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_PIEBurstThresh as text
%        str2double(get(hObject,'String')) returns contents of ET_PIEBurstThresh as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
for file=1:1:PIEdat.l_fn
    PIEdat.PIEburstThreshold = user_entry;
end    


% --- Executes during object creation, after setting all properties.
function ET_PIEBurstThresh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_PIEBurstThresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_FRETBurstThresh_Callback(hObject, eventdata, handles)
% hObject    handle to ET_FRETBurstThresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_FRETBurstThresh as text
%        str2double(get(hObject,'String')) returns contents of ET_FRETBurstThresh as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
for file=1:1:PIEdat.l_fn
    PIEdat.FRETburstThreshold = user_entry;   
end    


% --- Executes during object creation, after setting all properties.
function ET_FRETBurstThresh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_FRETBurstThresh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_ALPHA_Callback(hObject, eventdata, handles)
% hObject    handle to ET_ALPHA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_ALPHA as text
%        str2double(get(hObject,'String')) returns contents of ET_ALPHA as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry < 0 || user_entry > 1
	errordlg('You must enter a value between 0 and 1','Bad Input','modal')
	return
end
PIEdat.alpha = user_entry;


% --- Executes during object creation, after setting all properties.
function ET_ALPHA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_ALPHA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_GAMMA_Callback(hObject, eventdata, handles)
% hObject    handle to ET_GAMMA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_GAMMA as text
%        str2double(get(hObject,'String')) returns contents of ET_GAMMA as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry < 0 || user_entry > 10
	errordlg('The value you entered is either too small (<0) or too large (>10)','Bad Input','modal')
	return
end
PIEdat.gamma = user_entry;


% --- Executes during object creation, after setting all properties.
function ET_GAMMA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_GAMMA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when TCCD is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to TCCD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in PB_SaveResults.
function PB_SaveResults_Callback(hObject, eventdata, handles)
% hObject    handle to PB_SaveResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

SaveMolSortResults(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function AX_Dhist_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AX_Dhist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate AX_Dhist


% --- Executes on button press in PB_Reset.
function PB_Reset_Callback(hObject, eventdata, handles)
% hObject    handle to PB_Reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

InitializeUserVariables(hObject, eventdata, handles);


% --- Executes on button press in CB_AutomatedThreshold.
function CB_AutomatedThreshold_Callback(hObject, eventdata, handles)
% hObject    handle to CB_AutomatedThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CB_AutomatedThreshold

global PIEdat

if (get(hObject,'Value') == get(hObject,'Max'))
	PIEdat.AutoThreshold = true;
    set(handles.ET_IPDburstThreshold_PIE,'Enable','off');
    set(handles.ET_IPDburstThreshold_DA,'Enable','off');
    set(handles.ET_PIEBurstThresh,'Enable','off');
    set(handles.ET_FRETBurstThresh,'Enable','off');
    set(handles.ET_IPDthres_bg_fraction_FRET,'Enable','on')
    set(handles.ET_IPDthres_bg_fraction_PIE,'Enable','on')
else
	PIEdat.AutoThreshold = false;
    set(handles.ET_IPDburstThreshold_PIE,'Enable','on');
    set(handles.ET_IPDburstThreshold_DA,'Enable','on');
    set(handles.ET_PIEBurstThresh,'Enable','on');
    set(handles.ET_FRETBurstThresh,'Enable','on'); 
    set(handles.ET_IPDthres_bg_fraction_FRET,'Enable','off')
    set(handles.ET_IPDthres_bg_fraction_FRET,'Enable','off')
end


% --- Executes when PAN_IDPhistogram is resized.
function PAN_IDPhistogram_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to PAN_IDPhistogram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function ET_threshold_FRET_DA_Callback(hObject, eventdata, handles)
% hObject    handle to ET_threshold_FRET_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_threshold_FRET_DA as text
%        str2double(get(hObject,'String')) returns contents of ET_threshold_FRET_DA as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0
	errordlg('You must enter an integer','Bad Input','modal')
	return
end
PIEdat.FRET_thresholdDA = user_entry;


% --- Executes during object creation, after setting all properties.
function ET_threshold_FRET_DA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_threshold_FRET_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_directExc_Callback(hObject, eventdata, handles)
% hObject    handle to ET_directExc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_directExc as text
%        str2double(get(hObject,'String')) returns contents of ET_directExc as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry < 0 || user_entry >= 1
	errordlg('You must enter a value between 0 and 1','Bad Input','modal')
	return
end
PIEdat.directAexc = user_entry;


% --- Executes during object creation, after setting all properties.
function ET_directExc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_directExc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ET_IPDthres_bg_fraction_FRET_Callback(hObject, eventdata, handles)
% hObject    handle to ET_IPDthres_bg_fraction_FRET (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_IPDthres_bg_fraction_FRET as text
%        str2double(get(hObject,'String')) returns contents of ET_IPDthres_bg_fraction_FRET as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0 || user_entry >= 1
	errordlg('You must enter value between 0 and 1','Bad Input','modal')
	return
end
PIEdat.IPDthres_bg_fraction_FRET = user_entry;

% --- Executes during object creation, after setting all properties.
function ET_IPDthres_bg_fraction_FRET_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_IPDthres_bg_fraction_FRET (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function ET_IPDthres_bg_fraction_PIE_Callback(hObject, eventdata, handles)
% hObject    handle to ET_IPDthres_bg_fraction_PIE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ET_IPDthres_bg_fraction_PIE as text
%        str2double(get(hObject,'String')) returns contents of ET_IPDthres_bg_fraction_PIE as a double
global PIEdat
user_entry = str2double(get(hObject,'string'));
if isnan(user_entry) || user_entry <= 0 || user_entry >= 1
	errordlg('You must enter value between 0 and 1','Bad Input','modal')
	return
end
PIEdat.IPDthres_bg_fraction_PIE = user_entry;

% --- Executes during object creation, after setting all properties.
function ET_IPDthres_bg_fraction_PIE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ET_IPDthres_bg_fraction_PIE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PB_tccd.
function PB_tccd_Callback(hObject, eventdata, handles)
% hObject    handle to PB_tccd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

TCCDanalysis(hObject, eventdata, handles);
