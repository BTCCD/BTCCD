function DisplayTCSPC(hObject, ~, handles)

% % Copyright and Disclaimer
% %  This bundle of Matlab scripts is a GUI-based software for the Brightness-gated Two Color Coincidence (BTCCD) analysis of single molecule data from a confocal microscope. It includes 9 individual files (further referred to as �software�):
% %  TCCD.m
% %  InitializeUserVariables.m
% %  LoadInput.m
% %  DisplayTCSPC.m
% %  CalculateIPD_MoleculeSorting.m
% %  CalculateBursts.m
% %  SaveMolSortResults.m
% %  TCCDanalysis.m
% %  coinc.m
% % 
% % 
% % Copyright (C) 2019, Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University, Federal Republic of Germany. All rights reserved.
% % 
% %  Author: Henning H�fig, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University .
% % Contributor: Olessya Yukhnovets, AG Biophysics, I. Physikalisches Institut (IA), RWTH Aachen University.
% % 
% %  Corresponding author and contributor: J�rg Fitter, I. Physikalisches Institut (IA), RWTH Aachen University, (fitter@physik.rwth-aachen.de)
% % 
% %  Use of this software, with or without modification, is permitted provided that the following conditions are met:
% %    �    Modifications of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
% %    �    Modifications of source code must be clearly marked.
% %    �    Neither the name of the RWTH Aachen University nor the names of its contributors may be used to endorse or promote products derived from these scripts without specific prior written permission.
% %    �    For publications that result from the use of this software please contact J�rg Fitter (fitter@physik.rwth-aachen.de).
% %    �    Any publications that result from the use of this software shall reasonably refer to the publication H�fig H., et al. (2019) Brightness-Gated Two-Color Coincidence Detection Unravels Two Distinct Mechanisms in Bacterial Protein Translation Initiation. Manuscript submitted for publication.
% % 
% %  This software was written in the hope that it will be useful, but WITHOUT ANY WARRANTY.
% %  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
% %  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
% %  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
% %  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
% %  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

% DISPLAYTCSPC  Loads the micro and macro times for various channels and 
%               time windows and displays the corresponding TCSPC histograms.
%               User can see selected time windows for FRET and PIE.

% hObject       handle to PB_SaveApproximationXPLOR (see GCBO)
% eventdata     reserved - to be defined in a future version of MATLAB
% handles       structure with handles and user data (see GUIDATA)

% INPUTS        All input are taken from global cell variable 'PIEdat'
% OUTPUT        All outputs are written to global cell variable 'PIEdat'

% Inputs are:   INPUT{i} = input data i where each line represents a photon,
%                          columns are:
%                          1st column: Channel number
%                          2nd column: Macro time (in ns)
%                          3rd column: Micro time (in number of time bins 
%                                      since last laser excitation)
%               dt_start_window_FRET = micro start time for FRET window
%               dt_end_window_FRET = micro end time for FRET window
%               dt_starT_window_PIE = micro start time for PIE window
%               dt_end_window_PIE = micro end time for PIE window
% Outputs are:  t_*timewindow*_*channel*
%               dt_*timewindow*_*channel*
%               where   *timewindow* = FRET,PIE
%                       *channel* = D,A,DA

global PIEdat                                                              % global variable

% initialize variables
TCSPC_FRET_D = zeros(PIEdat.numberMicroChannels,2);
TCSPC_FRET_A = zeros(PIEdat.numberMicroChannels,2);
TCSPC_PIE_A = zeros(PIEdat.numberMicroChannels,2);
PIEdat.lifetime_edges = 1:PIEdat.numberMicroChannels;                      % set length of time window in bins

wbarh = waitbar(0,'TCSPC histogram is generated...');

for l=1:PIEdat.l_fn

    % Sorting out FRET donor signal (FRET time window + donor channel)
    FRET_window = PIEdat.dt_start_window_FRET < PIEdat.INPUT{l}(:,3) & PIEdat.INPUT{l}(:,3) < PIEdat.dt_end_window_FRET;
    DONOR_channel = PIEdat.INPUT{l}(:,1)==PIEdat.donor_chan;
%     DONOR_channel = (PIEdat.INPUT{l}(:,1)==2)|(PIEdat.INPUT{l}(:,1)==3);  %tmp
    INPUT_FRET_DONOR = FRET_window & DONOR_channel;                        % all signals in FRET time window
    m = find(INPUT_FRET_DONOR==1);                                         % all signals in donor channel
    dt_FRET_D = PIEdat.INPUT{l}(m,3);                                      % micro time of donor FRET events
    PIEdat.dt_FRET_D{l} = uint16(dt_FRET_D);                               % convert to integer of max. 65536
    PIEdat.t_FRET_D{l} = PIEdat.INPUT{l}(m,2);                             % macro time of donor FRET events

    clear DONOR_channel INPUT_FRET_DONOR m dt_FRET_D
    
    % Sorting out FRET acceptor signal (FRET time window + acceptor channel)
    ACCEPTOR_channel = PIEdat.INPUT{l}(:,1)==PIEdat.acceptor_chan;
    %ACCEPTOR_channel = (PIEdat.INPUT{l}(:,1)==0)|(PIEdat.INPUT{l}(:,1)==1);
    INPUT_FRET_ACCEPTOR = FRET_window & ACCEPTOR_channel;
    n = find(INPUT_FRET_ACCEPTOR==1);                                      % all signals in acceptor channel
    dt_FRET_A = PIEdat.INPUT{l}(n,3);                                      % micro time of acceptor FRET events
    PIEdat.dt_FRET_A{l} = uint16(dt_FRET_A);                               % convert to integer of max. 65536
    PIEdat.t_FRET_A{l} = PIEdat.INPUT{l}(n,2);                             % macro time of donor FRET events
    
    clear FRET_window INPUT_FRET_ACCEPTOR n dt_FRET_A
    
    % Merging donor + acceptor signal in FRET time window
    PIEdat.t_FRET_DA{l} = cat(1, PIEdat.t_FRET_D{l}, PIEdat.t_FRET_A{l});
    PIEdat.t_FRET_DA{l} = sort(PIEdat.t_FRET_DA{l});

    % Sorting out PIE acceptor signal (PIE time window + acceptor channel)
    PIE_window = PIEdat.dt_start_window_PIE < PIEdat.INPUT{l}(:,3) & PIEdat.INPUT{l}(:,3) < PIEdat.dt_end_window_PIE;
    INPUT_PIE = PIE_window & ACCEPTOR_channel;                             % same procedure as for FRET window
    p = find(INPUT_PIE==1);
    dt_PIE_A = PIEdat.INPUT{l}(p,3);
    PIEdat.dt_PIE_A{l} = uint16(dt_PIE_A);
    PIEdat.t_PIE_A{l} = PIEdat.INPUT{l}(p,2);
   
    clear ACCEPTOR_channel PIE_window INPUT_PIE p dt_PIE_A
    
    % Sorting out donor + acceptor signal (all time windows + both channels)
    PIEdat.t_ALL_DA{l} = cat(1,PIEdat.t_FRET_DA{l}, PIEdat.t_PIE_A{l});
    PIEdat.t_ALL_DA{l} = sort(PIEdat.t_ALL_DA{l});
       
    clear ACCEPTOR_channel PIE_window INPUT_PIE p dt_PIE_A
    
    waitbar(l/PIEdat.l_fn, wbarh);  
end

ca=gca;

% Set axes for plotting
axes(handles.AX_TCSPC);                                       % set current axes
cla;                                                           % clear current axes
    
% Build TCSPC histogram of total time window (FRET & PIE) for both channels

hist(PIEdat.INPUT{1}(:,3),PIEdat.lifetime_edges);               % plot TCSPC histogram of raw data
hold on;
xlabel('Time Channels')
ylabel('Counts')
%set(gca, 'YScale', 'log')

% Plot selected photons to TCSPC histogram
TCSPC_FRET_D(:,1) = PIEdat.lifetime_edges;                          % build TCSPC histogram
TCSPC_FRET_D(:,2) = hist(PIEdat.dt_FRET_D{1},PIEdat.lifetime_edges);
TCSPC_FRET_A(:,1) = PIEdat.lifetime_edges;                          % build TCSPC histogram
TCSPC_FRET_A(:,2) = hist(PIEdat.dt_FRET_A{1},PIEdat.lifetime_edges);
TCSPC_PIE_A(:,1) = PIEdat.lifetime_edges;
TCSPC_PIE_A(:,2) = hist(PIEdat.dt_PIE_A{1},PIEdat.lifetime_edges);
plot(TCSPC_FRET_D(:,2), 'Color',[0 1 1]);                    % plot FRET donor signal
plot(TCSPC_FRET_A(:,2), 'Color',[0 1 0]);                    % plot FRET acceptor signal
plot(TCSPC_PIE_A(:,2), 'Color', [1 0 0]);                    % plot PIE acceptor signal
xlim([0 PIEdat.numberMicroChannels]);
legend('Raw Data','Donor FRET','Acceptor FRET','Acceptor PIE')
hold off;

axes(ca);
guidata(hObject, handles);                                                 % update GUI data

clear TCSPC_FRET_D TCSPC_FRET_A TCSPC_PIE_A

close(wbarh);
